<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	
	//post data
	$booking_id = $_POST['booking_id'];
	$url = $_POST['url'];
	$comment = $_POST['comment'];
	
	$sql = mysqli_query($conn, "UPDATE booking SET comment = '$comment' WHERE booking_id = '$booking_id'");	
	
	if($url == "dashboard")		
		header('location:dashboard.php?code=comment&booking_id=' . $booking_id);
	else
		header('location:manage_appointment.php?code=comment&booking_id=' . $booking_id);
}

?>