<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	$username = $_POST['username'];
	$clinic_name = $_POST['clinic_name'];
	$owner_name = $_POST['owner_name'];
	$license_no = $_POST['license_no'];
	$region_id = $_POST['region_id'];
	$tel_no = $_POST['tel_no'];
	$open_time = $_POST['open_time'];
	$close_time = $_POST['close_time'];
	$email = $_POST['email'];
	
	$file_location 	= $_FILES['picture']['tmp_name'];
	$file_type		= $_FILES['picture']['type'];
	$file_name		= $_FILES['picture']['name'];
	
	if (empty($file_location))
	{
		$sql = mysqli_query($conn, "UPDATE clinic SET clinic_name = '$clinic_name',
																owner_name = '$owner_name',
																license_no = '$license_no',
																region_id = '$region_id',
																email = '$email',
																tel_no = '$tel_no',
																open_time = '$open_time',
																close_time = '$close_time'
																WHERE username = '$username'");
	}
	else
	{
		move_uploaded_file($file_location,"clinic/$file_name");
		
		$sql = mysqli_query($conn, "UPDATE clinic SET clinic_name = '$clinic_name',
																owner_name = '$owner_name',
																license_no = '$license_no',
																region_id = '$region_id',
																email = '$email',
																tel_no = '$tel_no',
																open_time = '$open_time',
																close_time = '$close_time',
																picture = '$file_name'
																WHERE username = '$username'");
	}
	
	
						
	
											
																	
	header('location:view_clinic.php?act=update&clinic_name=' . $clinic_name);
}

?>