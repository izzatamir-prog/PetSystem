<?php
include "conn/conn.php";
error_reporting(2);
session_start();

if (!empty($_SESSION['user_id']) AND !empty($_SESSION['password']))
{
  header('location:dashboard.php');
}
else
{
	
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
        .btn {
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 5px rgba(220, 53, 69, 0.5);
            transition: box-shadow 0.3s, transform 0.3s;
        }

        .btn::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300%;
            height: 300%;
            background-color: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%) rotate(45deg);
            transition: all 0.75s;
            opacity: 0;
        }

        .btn:hover::before {
            opacity: 1;
            width: 0;
            height: 0;
        }

        .btn:hover {
            box-shadow: 0 0 5px rgba(220, 53, 69, 0.5);
            transition: box-shadow 0.3s;
        }

        .btn {
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn:active {
            transform: scale(0.95);
        }
</style>

<body>

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
					
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
										<img src="img/logo.jpg" style="width: 180px; height: 160px;">
                                        <h1 class="h4 text-gray-900 mb-4">Create an Account</h1>
                                    </div>
									<?php
									
										//reset value
										$user_id = "";
										$password = "";
			
										//post login data
										if (isset($_POST['register']))
										{
											//post user data
											$user_id = $_POST['user_id'];
											$name = $_POST['name'];
											$email = $_POST['email'];
											$tel = $_POST['tel'];
											$password = $_POST['password'];
											
											$addLogin = mysqli_query($conn, "INSERT INTO login (user_id, password, level) VALUES ('$user_id', '$password', '3')");
											
											if($addLogin == true)
											{
												$addOwner = mysqli_query($conn, "INSERT INTO owner (username,
																									name,
																									email,
																									tel,
																									photo)
																							VALUES ('$user_id',
																									'$name',
																									'$email',
																									'$tel',
																									'avatar.jpg')");
																				
												
												if($addOwner == true)
												{
													$user_id = "";
													$name = "";
													$email = "";
													$tel = "";
													$password = "";
													
													echo "<div class='alert alert-success alert-dismissible'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																<a href='index.php' class='text-success'><strong>Thank you!</strong> You may login now.</a>
															</div>";
												}
												
											}
											else
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> Username $user_id already being used.
													</div>";
				
										}
									?>
                                    <form class="user" method="post">
                                        
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="user_id" value="<?php echo $user_id; ?>" placeholder="Username/ID" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="name" value="<?php echo $name; ?>"  placeholder="Full Name" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" name="email" value="<?php echo $email; ?>"  placeholder="Email" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="tel" value="<?php echo $tel; ?>"  placeholder="Phone Number" required />
                                        </div>
                                        <div class="form-group">
											<div class="input-group">
												<input type="password" class="form-control form-control-user" id="password" name="password" value="<?php echo $password; ?>"  placeholder="Password" required />
												<div class="input-group-append">
													<span class="input-group-text" style="border-top-right-radius: 10rem; border-bottom-right-radius: 10rem;">
														<i class="fas fa-eye" id="password-toggle"></i> <!-- Font Awesome icon for the "eye" -->
													</span>
												</div>
											</div>
                                        </div>
										<button type="submit" name="register" class="btn btn-danger btn-user btn-block">Sign me up</button>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="index.php">Already Registered? Login Now!</a>
                                    </div>
                                    <div class="text-center">
										<small>Copyright © 2024 <a href="#">Petto Familia</a>. All rights reserved.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- JavaScript -->
	<?php include("layout/script.php"); ?>
	<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
	<script>
    // Add a click event listener to the eye icon
        $(document).ready(function() {
        $('#password-toggle').on('click', function() {
            var passwordInput = $('#password');
            var icon = $(this);

            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash'); // Change the icon to an eye-slash
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye'); // Change the icon back to an eye
            }
        });
    });
	</script>
</body>

</html>
<?php
}
?>