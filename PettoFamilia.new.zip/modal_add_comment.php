
			  <!-- Modal -->
              <div class="modal fade" id="addComent<?php echo $row['booking_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p class="modal-title text-primary"><i class='fas fa-pen'></i> Write comment/review for #<?php echo $row['booking_id']; ?></p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="add_comment.php" enctype="multipart/form-data">
							<input type="hidden" class="form-control" name="booking_id" value="<?php echo $row['booking_id']; ?>" readonly />
                            <div class="modal-body">
								
								<div class="row gx-3 mb-3">
									 <div class="col-md-12">
										<label class="small mb-1">Comment</label>
										<textarea class="form-control" name="comment" rows="5" placeholder="Write comment or review for this booking..." required ><?php echo $row['comment']; ?></textarea>
									 </div>
								</div>
								
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Submit</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->