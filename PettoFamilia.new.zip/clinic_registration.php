<?php
include "conn/conn.php";
error_reporting(2);
session_start();

if (!empty($_SESSION['user_id']) AND !empty($_SESSION['password']))
{
  header('location:dashboard.php');
}
else
{
	
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
        .btn {
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 5px rgba(220, 53, 69, 0.5);
            transition: box-shadow 0.3s, transform 0.3s;
        }

        .btn::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300%;
            height: 300%;
            background-color: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%) rotate(45deg);
            transition: all 0.75s;
            opacity: 0;
        }

        .btn:hover::before {
            opacity: 1;
            width: 0;
            height: 0;
        }

        .btn:hover {
            box-shadow: 0 0 5px rgba(220, 53, 69, 0.5);
            transition: box-shadow 0.3s;
        }

        .btn {
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn:active {
            transform: scale(0.95);
        }
</style>
<body>

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-6 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
					
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="p-5">
                                    <div class="text-center">
										<img src="img/logo.jpg" style="width: 180px; height: 160px;">
                                        <h1 class="h4 text-gray-900 mb-4">Clinic Registration</h1>
                                    </div>
									<?php
									
									
										//reset value
										$user_id = "";
										$password = "";
			
										//post login data
										if (isset($_POST['register']))
										{
											//post user data
											$user_id = $_POST['user_id'];
											$clinic_name = $_POST['clinic_name'];
											$owner_name = $_POST['owner_name'];
											$license_no = $_POST['license_no'];
											$region_id = $_POST['region_id'];
											$email = $_POST['email'];
											$tel_no = $_POST['tel_no'];
											$open_time = $_POST['open_time'];
											$close_time = $_POST['close_time'];
											$password = $_POST['password'];
						
											//upload image
											$file_location 	= $_FILES['picture']['tmp_name'];
											$file_type		= $_FILES['picture']['type'];
											$file_name		= $_FILES['picture']['name'];
											move_uploaded_file($file_location,"clinic/$file_name");
											
											$addLogin = mysqli_query($conn, "INSERT INTO login (user_id, password, level) VALUES ('$user_id', '$password', '2')");
											
											if($addLogin == true)
											{
												$sql = mysqli_query($conn, "INSERT INTO clinic (username,
																									clinic_name,
																									owner_name,
																									license_no,
																									region_id,
																									email,
																									tel_no,
																									open_time,
																									close_time,
																									picture)
																							VALUES ('$user_id',
																									'$clinic_name',
																									'$owner_name',
																									'$license_no',
																									'$region_id',
																									'$email',
																									'$tel_no',
																									'$open_time',
																									'$close_time',
																									'$file_name')");
																				
												
												if($sql == true)
												{
													$user_id = "";
													$clinic_name = "";
													$owner_name =  "";
													$license_no =  "";
													$region_id = "";
													$email = "";
													$tel_no = "";
													$open_time = "";
													$close_time = "";
													$password = "";
													
													echo "<div class='alert alert-success alert-dismissible'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																<a href='index.php' class='text-success'><strong>Thank you!</strong> Your registration is successfull. You may login now.</a>
															</div>";
												}
												
											}
											else
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> Username $user_id already being used.
													</div>";
				
										}
									?>
                                    <form class="user" method="post" enctype="multipart/form-data">
                                        <div class="form-group">
											<label class="small ml-2 text-success">1. Clinic Details</label>
                                            <input type="text" class="form-control form-control-user" name="clinic_name" value="<?php echo $clinic_name; ?>"  placeholder="Clinic Name" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="owner_name" value="<?php echo $owner_name; ?>"  placeholder="Clinic's Owner Name" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="license_no" value="<?php echo $license_no; ?>"  placeholder="License No." required />
                                        </div>
                                        <div class="form-group">
                                            <select type="text" class="form-control form-control-user" style="padding: .5rem 1rem; height: calc(1.5em + .75rem + 20px);" name="region_id" placeholder="Region" required>
												<option value="">Region</option>
												<?php
													$sqlRegion = mysqli_query($conn, "SELECT * FROM region");
													while($rowRegion = mysqli_fetch_array($sqlRegion))
														echo "<option value='$rowRegion[region_id]'>$rowRegion[region]</option>"
												?>
											</select>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" name="email" value="<?php echo $email; ?>"  placeholder="Email Address" required />
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="tel_no" value="<?php echo $tel_no; ?>"  placeholder="Phone Number" required />
                                        </div>
                                        <div class="form-group">
                                            <label for="choose-file" class="btn btn-outline-dark btn-user btn-block text-left" id="choose-file-label" required />
                                               Clinic Image
                                            </label>
                                            <input name="picture" type="file" id="choose-file" accept=".jpg,.jpeg,.png" style="display: none;" required />
                                        </div>
										<div class="row gx-3 mb-3">
                                                <div class="col-md-6">
													<label class="small ml-2 text-success">2. Open Time</label>
													<input type="time" class="form-control form-control-user" name="open_time" value="<?php echo $open_time; ?>"  placeholder="Open Time" required />
                                                </div>
                                                <div class="col-md-6">
													<label class="small ml-2 text-success">Closed Time</label>
													<input type="time" class="form-control form-control-user" name="close_time" value="<?php echo $close_time; ?>"  placeholder="Closed Time" required />
                                                </div>
										</div>
                                        
                                        <div class="form-group">
											<label class="small ml-2 text-success">3. Login Access</label>
                                            <input type="text" class="form-control form-control-user" name="user_id" value="<?php echo $user_id; ?>" placeholder="Username/ID" required />
                                        </div>
                                        <div class="form-group">
											<div class="input-group">
												<input type="password" class="form-control form-control-user" id="password" name="password" value="<?php echo $password; ?>"  placeholder="Password" required />
												<div class="input-group-append">
													<span class="input-group-text" style="border-top-right-radius: 10rem; border-bottom-right-radius: 10rem;">
														<i class="fas fa-eye" id="password-toggle"></i> <!-- Font Awesome icon for the "eye" -->
													</span>
												</div>
											</div>
                                        </div>
										<button type="submit" name="register" class="btn btn-danger btn-user btn-block">Register now!</button>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="index.php">Already Registered? Login Now!</a>
                                    </div>
                                    <div class="text-center">
										<small>Copyright © 2024 <a href="#">Petto Familia</a>. All rights reserved.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- JavaScript -->
	<?php include("layout/script.php"); ?>
	<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
	<script>
		$(document).ready(function () {
		$('#choose-file').change(function () {
			var i = $(this).prev('label').clone();
			var file = $('#choose-file')[0].files[0].name;
			$(this).prev('label').text(file);
		}); 
	 });
	 </script>
	<script>
    // Add a click event listener to the eye icon
        $(document).ready(function() {
        $('#password-toggle').on('click', function() {
            var passwordInput = $('#password');
            var icon = $(this);

            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash'); // Change the icon to an eye-slash
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye'); // Change the icon back to an eye
            }
        });
    });
	</script>
</body>

</html>
<?php
}
?>