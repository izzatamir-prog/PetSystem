<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<script src="Chart.js/Chart.bundle.js"></script>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>
				<!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Appointment Report</h1>
						<small>Appointment Graph Report</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Generate Appointment Graph Report</h6>
								</div>
								<div class="card-body">
									
									<form method="post" enctype="multipart/form-data">
										<div class="row gx-3 mb-3">
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Clinic</label>
													<select class='form-control' name='clinic_id' required>
														<option value=''>- choose clinic -</option>
														<?php
															$sqlC = mysqli_query($conn, "SELECT * FROM clinic");
															while($rowC = mysqli_fetch_array($sqlC))
															{
																echo "<option value='$rowC[username]'>$rowC[clinic_name]</option>";
															}
														?>
													</select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Year</label>
													<select class='form-control' name='year' required>
														<option value=''>- choose year -</option>
														<option value='2024'>2024</option>
														<option value='2025'>2025</option>
														<option value='2026'>2026</option>
														<option value='2027'>2027</option>
														<option value='2028'>2028</option>
														<option value='2029'>2029</option>
													</select>
                                                </div>
										</div>
										
										
										<!-- Reset and Submit button-->
										<button class="btn btn-dark btn-icon-split" type="reset">
											<span class="icon text-white-50">
												<i class="fas fa-dice"></i>
											</span>
											<span class="text">Reset</span>
										</button>
										<button class="btn btn-primary btn-icon-split" type="submit" name="generate">
											<span class="icon text-white-50">
												<i class="fas fa-check"></i>
											</span>
											<span class="text">Generate</span>
										</button>
									</form>
									
									<?php
										if(isset($_POST['generate']))
										{
											$clinic_id = $_POST['clinic_id'];
											$year = $_POST['year'];
											
											//get clinic name
											$sqlC = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$clinic_id'");
											$rowC = mysqli_fetch_array($sqlC);
											$clinic_name = $rowC['clinic_name'];
											
											/* calculate total appointment */
											$sqlM1 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '1'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM1 = mysqli_fetch_array($sqlM1);
											
											$sqlM2 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '2'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM2 = mysqli_fetch_array($sqlM2);
											
											
											$sqlM3 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '3'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM3 = mysqli_fetch_array($sqlM3);
											
											
											$sqlM4 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '4'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM4 = mysqli_fetch_array($sqlM4);
											
											
											$sqlM5 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '5'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM5 = mysqli_fetch_array($sqlM5);
											
											
											
											$sqlM6 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '6'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM6 = mysqli_fetch_array($sqlM6);
											
											
											
											$sqlM7 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '7'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM7 = mysqli_fetch_array($sqlM7);
											
											
											$sqlM8 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '8'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM8 = mysqli_fetch_array($sqlM8);
											
											
											$sqlM9 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '9'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM9 = mysqli_fetch_array($sqlM9);
											
											
											$sqlM10 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '10'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM10 = mysqli_fetch_array($sqlM10);
											
											
											$sqlM11 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '11'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM11 = mysqli_fetch_array($sqlM11);
											
											
											
											$sqlM12 = mysqli_query($conn, "SELECT COUNT(*) AS total_booking FROM booking
																							WHERE MONTH(booking_date) = '12'
																							AND YEAR(booking_date) = '$year'
																							AND clinic_id = '$clinic_id'");
											$rowM12 = mysqli_fetch_array($sqlM12);
											
											
											//total cancelled
											
											/* calculate total cancelled booking */
											$sqlM1C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '1'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM1C = mysqli_fetch_array($sqlM1C);
											
											$sqlM2C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '2'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM2C = mysqli_fetch_array($sqlM2C);
											
											
											$sqlM3C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '3'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM3C = mysqli_fetch_array($sqlM3C);
											
											
											$sqlM4C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '4'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM4C = mysqli_fetch_array($sqlM4C);
											
											
											$sqlM5C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '5'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM5C = mysqli_fetch_array($sqlM5C);
											
											
											
											$sqlM6C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '6'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM6C = mysqli_fetch_array($sqlM6C);
											
											
											
											$sqlM7C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '7'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM7C = mysqli_fetch_array($sqlM7C);
											
											
											$sqlM8C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '8'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM8C = mysqli_fetch_array($sqlM8C);
											
											
											$sqlM9C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '9'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM9C = mysqli_fetch_array($sqlM9C);
											
											
											$sqlM10C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '10'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM10C = mysqli_fetch_array($sqlM10C);
											
											
											$sqlM11C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '11'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM11C = mysqli_fetch_array($sqlM11C);
											
											
											
											$sqlM12C = mysqli_query($conn, "SELECT COUNT(*) AS total_cancelled FROM booking
																							WHERE MONTH(booking_date) = '12'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Cancelled'
																							AND clinic_id = '$clinic_id'");
											$rowM12C = mysqli_fetch_array($sqlM12C);
											
											/* calculate total completed booking */
											$sqlM1Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '1'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM1Completed = mysqli_fetch_array($sqlM1Completed);
											
											$sqlM2Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '2'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM2Completed = mysqli_fetch_array($sqlM2Completed);
											
											
											$sqlM3Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '3'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM3Completed = mysqli_fetch_array($sqlM3Completed);
											
											
											$sqlM4Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '4'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM4Completed = mysqli_fetch_array($sqlM4Completed);
											
											
											$sqlM5Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '5'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM5Completed = mysqli_fetch_array($sqlM5Completed);
											
											
											
											$sqlM6Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '6'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM6Completed = mysqli_fetch_array($sqlM6Completed);
											
											
											
											$sqlM7Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '7'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM7Completed = mysqli_fetch_array($sqlM7Completed);
											
											
											$sqlM8Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '8'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM8Completed = mysqli_fetch_array($sqlM8Completed);
											
											
											$sqlM9Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '9'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM9Completed = mysqli_fetch_array($sqlM9Completed);
											
											
											$sqlM10Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '10'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM10Completed = mysqli_fetch_array($sqlM10Completed);
											
											
											$sqlM11Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '11'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM11Completed = mysqli_fetch_array($sqlM11Completed);
											
											
											
											$sqlM12Completed = mysqli_query($conn, "SELECT COUNT(*) AS total_completed FROM booking
																							WHERE MONTH(booking_date) = '12'
																							AND YEAR(booking_date) = '$year'
																							AND booking_status = 'Completed'
																							AND clinic_id = '$clinic_id'");
											$rowM12Completed = mysqli_fetch_array($sqlM12Completed);
											
											
											
											
											echo "<hr/>
													<h6 class='m-0 font-weight-bold text-primary'>Appointment Graph Report For Clinic $clinic_name, Year $year</h6>
													<br />
													<div class='visible'>
														<div class='container'>
															<canvas class='col-md-12 grid-margin stretch-card' id='myChart'></canvas>
														</div>
													</div>";
												
										}
										?>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>
	<script>
						var ctx = document.getElementById("myChart");
						var myBarChart = new Chart(ctx, {
							type: 'bar',
							data: {
								labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
								datasets: [{
										label: 'Total Appointment for Year <?php echo $year; ?>',
										data: [<?php echo $rowM1['total_booking'] . "," .
															$rowM2['total_booking'] . "," .
															$rowM3['total_booking'] . "," .
															$rowM4['total_booking'] . "," .
															$rowM5['total_booking'] . "," .
															$rowM6['total_booking'] . "," .
															$rowM7['total_booking'] . "," .
															$rowM8['total_booking'] . "," .
															$rowM9['total_booking'] . "," .
															$rowM10['total_booking'] . "," .
															$rowM11['total_booking'] . "," .
															$rowM12['total_booking']; ?>],
										backgroundColor: [
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)'
										],
										borderColor: [
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)',
											'rgba(255, 206, 86, 1)'
										],
										borderWidth: 1
									},
									{
										label: 'Total Cancelled Appointment for Year <?php echo $year; ?>',
										data: [<?php echo $rowM1C['total_cancelled'] . "," .
															$rowM2C['total_cancelled'] . "," .
															$rowM3C['total_cancelled'] . "," .
															$rowM4C['total_cancelled'] . "," .
															$rowM5C['total_cancelled'] . "," .
															$rowM6C['total_cancelled'] . "," .
															$rowM7C['total_cancelled'] . "," .
															$rowM8C['total_cancelled'] . "," .
															$rowM9C['total_cancelled'] . "," .
															$rowM10C['total_cancelled'] . "," .
															$rowM11C['total_cancelled'] . "," .
															$rowM12C['total_cancelled']; ?>],
										backgroundColor: [
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)'
										],
										borderColor: [
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)',
											'rgba(230, 82, 81, 1)'
										],
										borderWidth: 1
									},
									{
										label: 'Total Completed Appointment for Year <?php echo $year; ?>',
										data: [<?php echo $rowM1Completed['total_completed'] . "," .
															$rowM2Completed['total_completed'] . "," .
															$rowM3Completed['total_completed'] . "," .
															$rowM4Completed['total_completed'] . "," .
															$rowM5Completed['total_completed'] . "," .
															$rowM6Completed['total_completed'] . "," .
															$rowM7Completed['total_completed'] . "," .
															$rowM8Completed['total_completed'] . "," .
															$rowM9Completed['total_completed'] . "," .
															$rowM10Completed['total_completed'] . "," .
															$rowM11Completed['total_completed'] . "," .
															$rowM12Completed['total_completed']; ?>],
										backgroundColor: [
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)'
										],
										borderColor: [
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)',
											'rgba(27, 207, 180, 1)'
										],
										borderWidth: 1
									}]
							},
							options: {
								scales: {
									yAxes: [{
											ticks: {
												beginAtZero: true,
												stepSize: 1
											}
										}]
								}
							}
						});
	</script>
</body>

</html>

<?php
}
?>