
			  <!-- Modal -->
              <div class="modal fade" id="reminder<?php echo $row['vaccination_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p class="modal-title text-primary"><i class='fas fa-paper-plane'></i> Email Vaccination Reminder</p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="email_reminder.php" enctype="multipart/form-data">
							<input type="hidden" class="form-control" name="vaccination_id" value="<?php echo $row['vaccination_id']; ?>" readonly />
							<input type="hidden" class="form-control" name="owner_email" value="<?php echo $rowOwner['email']; ?>" readonly />
                            <div class="modal-body">
								
								<div class="row gx-3 mb-3">
									 <div class="col-md-6">
										<label class="small mb-1">Pet Owner</label>
										<input type="text" class="form-control" name="owner_name" value="<?php echo $rowOwner['name']; ?>" readonly />
									 </div>
									 <div class="col-md-6">
										<label class="small mb-1">Pet</label>
										<input type="text" class="form-control" name="pet_name" value="<?php echo $rowPet['pet_name']; ?>" readonly />
									 </div>
								</div>
								
								<div class="row gx-3 mb-3">
									 <div class="col-md-6">
										<label class="small mb-1">Last Vaccinated</label>
										<input type="text" class="form-control" name="last_vaccinated" value="<?php echo $vDateStringFormat; ?>" readonly />
									 </div>
									 <div class="col-md-6">
										<label class="small mb-1">Expired Date</label>
										<input type="text" class="form-control" name="expired_date" value="<?php echo $expDateStringFormat; ?>" readonly />
									 </div>
								</div>
								
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Email Reminder</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->