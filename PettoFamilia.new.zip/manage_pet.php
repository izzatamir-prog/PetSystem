<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
.img-pet
{
    height: 7rem;
}
</style>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Your Pet</h1>
						<small>Manage Your Pet</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">List of Your Pet</h6>
								</div>
								<div class="card-body">
									<?php
										
										$act = $_GET['act'];
										
										if ($act=='del')
										{
											$pet_id =  $_GET['pet_id'];
											$pet_name =  $_GET['pet_name'];
											
											$deletePet = mysqli_query($conn, "DELETE FROM pet WHERE pet_id = '$pet_id'");
											
											if($deletePet == true)
											{
												echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
														  <strong>Thank you!</strong> Your pet <b>$pet_name</b> successfully removed.
														  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
															<span aria-hidden='true'>&times;</span>
														  </button>
														</div>";
											}
												
										}
									?>
									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>No.</th>
													<th>Photo</th>
													<th>Pet</th>
													<th>Type</th>
													<th>Age</th>
													<th>Sex</th>
													<th>Weight</th>
													<th>Genetic</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												
												$no = 1;
												$sql = mysqli_query($conn, "SELECT * FROM pet WHERE owner_id = '$_SESSION[user_id]'");
												while($row = mysqli_fetch_array($sql))
												{
													//get type id
													$sqlType = mysqli_query($conn, "SELECT * FROM pet_type WHERE type_id = '$row[type_id]'");
													$rowType = mysqli_fetch_array($sqlType);
													
													//highlight Pet
													if($row['sex_id'] == "F")
														$sex = "<span class='badge badge-danger'>$row[sex_id]</span>";
													else
														$sex = "<span class='badge badge-primary'>$row[sex_id]</span>";
														
													
													echo "<tr>	
															<td>$no</td>
															<td><img src='pet/$row[photo]' class='img-pet'></td>
															<td>$row[pet_name]</td>
															<td>$rowType[type_name]</td>
															<td>$row[age_year] Year,<br />$row[age_month] Month</td>
															<td>$sex</td>
															<td>$row[weight]</td>
															<td>$row[genetic]</td>
															<td>
																<a href='#' data-toggle='modal'
																	data-target='#updatePet$row[pet_id]'>
																	<i class='fas fa-pen text-primary'></i>
																</a>
																					
																
																<a href='manage_pet.php?act=del&pet_id=$row[pet_id]&pet_name=$row[pet_name]'
																	data-toggle='tooltip' data-placement='left' title='Remove'
																	onclick=\"return confirm('Are you sure you want to remove Pet $row[pet_name]?');\">
																	<i class='fas fa-trash text-danger'></i>
																</a>
																</td>
															</tr>";
												
													$no++;
													include "modal_update_pet.php";
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>