<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
.img-staff
{
    height: 7rem;
}
</style>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>
				<!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Your's Staff</h1>
						<small>Manage Your's Staff</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">List of Veterinary Clinic's Staff for Your Clinic</h6>
								</div>
								<div class="card-body">
									<?php
										
										$act = $_GET['act'];
										
										if ($act=='del')
										{
											$staff_id =  $_GET['staff_id'];
											$name =  $_GET['name'];
											
											$deleteAcc = mysqli_query($conn, "DELETE FROM login WHERE user_id = '$staff_id'");
											$deleteStaff = mysqli_query($conn, "DELETE FROM clinic_staff WHERE staff_id = '$staff_id'");
											
											if(($deleteAcc == true) && ($deleteStaff == true))
											{
												echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
														  <strong>Thank you!</strong> Staff <b>$name</b> account successfully removed.
														  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
															<span aria-hidden='true'>&times;</span>
														  </button>
														</div>";
											}
												
										}
										else if ($act=='reset')
										{
											$staff_id =  $_GET['staff_id'];
											$name =  $_GET['name'];
											
											$sql = mysqli_query($conn, "UPDATE login SET password = '$staff_id' WHERE user_id = '$staff_id'");
											
											if($sql == true)
											{
												echo "<div class='alert alert-success alert-dismissible'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
															<strong>Thank you!</strong> Staff's $name Password successfully reset. (New Password = $staff_id).
													</div>";
											}
												
										}
										
									?>
									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>No</th>
													<th>Staff ID</th>
													<th>Name</th>
													<th>Email</th>
													<th>Phone No.</th>
													<th>Gender</th>
													<th>Experience</th>
													<th>Photo</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												
												
												$no = 1;
												$sql = mysqli_query($conn, "SELECT * FROM clinic_staff WHERE clinic_id = '$_SESSION[user_id]'");
												while($row = mysqli_fetch_array($sql))
												{
													echo "<tr>	
															<td>$no</td>
															<td>$row[staff_id]</td>
															<td>$row[name]</td>
															<td>$row[email]</td>
															<td>$row[phone_no]</td>
															<td>$row[gender_id]</td>
															<td>$row[experience]</td>
															<td>
																<img class='img-staff' src='photo/$row[photo]' alt='photo' />
															</td>
															<td>
																<a href='manage_staff.php?act=reset&staff_id=$row[staff_id]&name=$row[name]'
																	data-toggle='tooltip' data-placement='left' title='Reset Password'
																	onclick=\"return confirm('Are you sure you want to reset password for Staff $row[name]?');\">
																	<i class='fas fa-sync-alt text-warning'></i>
																</a>
																
																<a href='#' data-toggle='modal'
																	data-target='#updateStaff$row[staff_id]'>
																	<i class='fas fa-pen text-primary'></i>
																</a>
																	
																<a href='manage_staff.php?act=del&staff_id=$row[staff_id]&name=$row[name]'
																	data-toggle='tooltip' data-placement='left' title='Remove'
																	onclick=\"return confirm('Are you sure you want to remove Staff $row[name]?');\">
																	<i class='fas fa-trash text-danger'></i>
																</a>
																</td>
															</tr>";
															
															$no++;
															include "modal_update_staff.php";
												
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>