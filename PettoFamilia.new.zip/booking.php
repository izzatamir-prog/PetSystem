<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
		
		date_default_timezone_set("Asia/Kuala_Lumpur");

		// function utk	generate unique id
		$queryx  = mysqli_query($conn, "SELECT * FROM booking ORDER BY booking_id DESC LIMIT 1");
		$fetchx  = mysqli_fetch_array($queryx);

		if($fetchx[0]==NULL)
			$booking_id = "BOOKING00001";
		else
		{
			$patterns 	  = array("/[123456789].*/",);
			$replacements = '';
			$x= preg_replace($patterns, $replacements, $fetchx[0]);
			$x_= explode($x, $fetchx[0]);
			$nolast		= implode("",$x_);

			$newlast	= $nolast + 1;
			$length		= strlen($x);
			$initlength = strlen($nolast);
			$newlength  = strlen($newlast);
			$last		= substr($fetchx[0], -1);
			$zero		= substr($fetchx[0], 0, $length);
			
			if($newlength > $initlength)
				$zero = substr($zero, 0, -1);

			$booking_id  = $zero.$newlast;
		}

		$clinic_id = $_POST['clinic_id'];
		$booking_date = $_POST['booking_date'];
		$slot_id = $_POST['slot_id'];
		$pet_id = $_POST['pet_id'];
		$treatment_id = $_POST['treatment_id'];
		$note = $_POST['note'];
		$owner_id = $_SESSION['user_id'];
		
		if(($pet_id == "") || ($treatment_id == ""))
		{
			echo "<script>window.alert('Ooopsss! Sorry... Seems like there is a problem with your booking. Either pet or treatment are not being choosen. Contact admin for further details. Thank you.'); window.location=('book_treatment.php')</script>";

		}
		else
		{
			mysqli_query($conn, "INSERT INTO booking (booking_id,
													clinic_id,
													booking_date,
													slot_id,
													pet_id,
													treatment_id,
													note,
													owner_id) 
										VALUES ('$booking_id',
													'$clinic_id',
													'$booking_date',
													'$slot_id',
													'$pet_id',
													'$treatment_id',
													'$note',
													'$owner_id')");
				
		
			echo "<script>window.alert('Thank You! Your appointment booking is successful...'); window.location=('treatment_history.php')</script>";

			
	
		}
		
		
		
																
		
	
}
?>