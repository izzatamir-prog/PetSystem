<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Vaccination Reminder</h1>
						<small>Pet Vaccination Reminder</small>
                    </div>

                    <!-- Content Row -->
					
					<?php
						
						$code = $_GET['code'];
						
						if($code == "sent")
						{		
							echo "<div class='alert alert-success alert-dismissible'>
										<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
										<strong>Thank you!</strong> Vaccination Reminder successfully sent.
									</div>";
						}
						else if($code == "notsent")
						{		
							echo "<div class='alert alert-danger alert-dismissible'>
										<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
										<strong>Sorry!</strong> Vaccination Reminder not sent to the respective owner. There is might be an error with their email.
									</div>";
						}
					?>

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">List of Vaccination Reminder</h6>
								</div>
								<div class="card-body">
									
									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>Pet Owner</th>
													<th>Pet</th>
													<th>Last Vaccinated</th>
													<th>Expired Date</th>
													<th>Status</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												
												$sql = mysqli_query($conn, "SELECT * FROM vaccination_reminder WHERE clinic_id = '$_SESSION[user_id]'");
												while($row = mysqli_fetch_array($sql))
												{
													//owner name
													$sqlOwner = mysqli_query($conn, "SELECT * FROM owner WHERE username = '$row[owner_id]'");
													$rowOwner = mysqli_fetch_array($sqlOwner);
													
													//pet details
													$sqlPet = mysqli_query($conn, "SELECT * FROM pet WHERE pet_id = '$row[pet_id]'");
													$rowPet = mysqli_fetch_array($sqlPet);
													
													//vaccination_date
													$vDateString = str_replace('-', '/', $row['vaccination_date']);
													$vDateStringFormat = date('d/m/Y', strtotime($vDateString));
													
													//expired_date
													$expDateString = str_replace('-', '/', $row['expired_date']);
													$expDateStringFormat = date('d/m/Y', strtotime($expDateString));
													
													//cek reminder status
													if($row['status'] == NULL)
														$status = "<span class='badge badge-warning'>Pending Reminder</span>";
													else
														$status = "<span class='badge badge-success'>Reminder Sent</span>";
																		

													echo "<tr>	
															<td>$rowOwner[name]</td>			
															<td>$rowPet[pet_name]</td>
															<td>$vDateStringFormat</td>
															<td>$expDateStringFormat</td>
															<td>$status</td>
															<td>
																<a href='#' data-toggle='modal'
																	data-target='#reminder$row[vaccination_id]'>
																	<i class='fas fa-paper-plane text-primary'></i>
																</a>
															</td>
															</tr>";
																														
													include "modal_email_reminder.php";
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>