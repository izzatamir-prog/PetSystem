<?php
include "conn/conn.php";
error_reporting(2);
session_start();

if (!empty($_SESSION['user_id']) AND !empty($_SESSION['password']))
{
  header('location:dashboard.php');
}
else
{
	
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
        .btn {
            position: relative;
            overflow: hidden;
            box-shadow: 0 0 5px rgba(220, 53, 69, 0.5);
            transition: box-shadow 0.3s, transform 0.3s;
        }

        .btn::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300%;
            height: 300%;
            background-color: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%) rotate(45deg);
            transition: all 0.75s;
            opacity: 0;
        }

        .btn:hover::before {
            opacity: 1;
            width: 0;
            height: 0;
        }

        .btn:hover {
            box-shadow: 0 0 5px rgba(220, 53, 69, 0.5);
            transition: box-shadow 0.3s;
        }

        .btn {
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn:active {
            transform: scale(0.95);
        }
</style>

<body>

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
					
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
										<img src="img/logo.jpg" style="width: 180px; height: 160px;">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                    </div>
									<?php
			
										//post login data
										if (isset($_POST['login']))
										{
											//post data user id and password
											$user_id = $_POST['user_id'];
											$password = $_POST['password'];
											
											//authenticate user id and password
											$login = mysqli_query($conn, "SELECT * FROM login WHERE user_id = '$user_id' AND password = '$password'");
											$success = mysqli_num_rows($login);
											$row = mysqli_fetch_array($login);

											if ($success > 0){
												
												//cek account status
												if($row['status'] == "Active")
												{
													session_start();		
											
													$_SESSION['user_id'] = $row['user_id'];
													$_SESSION['password'] = $row['password'];				
													$_SESSION['level'] = $row['level'];	
													
													
													if($row['level'] == 1)
													{
														$sql = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$row[user_id]'");
														$row = mysqli_fetch_array($sql);
														$_SESSION['level_type'] = "Admin";
													} 
													else if($row['level'] == 3)
													{
														$sql = mysqli_query($conn, "SELECT * FROM owner WHERE username = '$row[user_id]'");
														$row = mysqli_fetch_array($sql);
														$_SESSION['level_type'] = "Pet Owner";
													}
													
													//echo $_SESSION['level'];
													
													echo "<script>window.location = 'dashboard.php';</script>";

												}
												else
												{
													echo "<div class='alert alert-danger alert-dismissible'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																<strong>Sorry!</strong> Your account was not active. Please contact administrator for further details. Thank you.
															</div>";
												}
											}
											else
											{
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> Authentication failed.
													</div>";
											}
				
										}
									?>
                                    <form class="user" method="post">
										<div class="form-group">
											<div class="input-group">
												<input type="text" class="form-control form-control-user" name="user_id" placeholder="Username/ID" required />
												<div class="input-group-append">
													<span class="input-group-text" style="border-top-right-radius: 10rem; border-bottom-right-radius: 10rem;">
														<i class="fas fa-user-circle"></i>
													</span>
												</div>
											</div>
                                        </div>
                                        <div class="form-group">
											<div class="input-group">
												<input type="password" class="form-control form-control-user" id="password" name="password" placeholder="Password" required />
												<div class="input-group-append">
													<span class="input-group-text" style="border-top-right-radius: 10rem; border-bottom-right-radius: 10rem;">
														<i class="fas fa-eye" id="password-toggle"></i> <!-- Font Awesome icon for the "eye" -->
													</span>
												</div>
											</div>
                                        </div>
										<button type="submit" name="login" class="btn btn-danger btn-user btn-block">Log me in</button>
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="register.php">New Member? Sign up today!</a><br />
                                        <a class="small text-info" href="clinic_registration.php">Clinic Owner? Register here!</a>
                                    </div>
                                    <div class="text-center">
										<small>Copyright © 2024 <a href="#">Petto Familia</a>. All rights reserved.</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

    <!-- JavaScript -->
	<?php include("layout/script.php"); ?>
	<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
	<script>
    // Add a click event listener to the eye icon
        $(document).ready(function() {
        $('#password-toggle').on('click', function() {
            var passwordInput = $('#password');
            var icon = $(this);

            if (passwordInput.attr('type') === 'password') {
                passwordInput.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash'); // Change the icon to an eye-slash
            } else {
                passwordInput.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye'); // Change the icon back to an eye
            }
        });
    });
	</script>
</body>

</html>
<?php
}
?>