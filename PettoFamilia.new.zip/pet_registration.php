<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['photo']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Pet Registration</h1>
						<small>Add Your Pet Details</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Your Pet Information</h6>
								</div>
								<div class="card-body">
									<?php
									
										//pet registration
										if (isset($_POST['register']))
										{
											//post pet data
											$pet_name = $_POST['pet_name'];
											$type_id = $_POST['type_id'];
											$age_year = $_POST['age_year'];
											$age_month = $_POST['age_month'];
											$sex_id = $_POST['sex_id'];
											$weight = $_POST['weight'];
											$genetic = $_POST['genetic'];
											
											$file_location 	= $_FILES['photo']['tmp_name'];
											$file_type		= $_FILES['photo']['type'];
											$file_name		= $_FILES['photo']['name'];
											
											move_uploaded_file($file_location,"pet/$file_name");
											
											
											$sql = mysqli_query($conn, "INSERT INTO pet (pet_name,
																							type_id,
																							age_year,
																							age_month,
																							sex_id,
																							weight,
																							genetic,
																							photo,
																							owner_id)
																					VALUES ('$pet_name',
																							'$type_id',
																							'$age_year',
																							'$age_month',
																							'$sex_id',
																							'$weight',
																							'$genetic',
																							'$file_name',
																							'$_SESSION[user_id]')");
											
											if($sql == true)
											{
													$pet_name = "";
													$type_id = "";
													$age_year = "";
													$age_month = "";
													$sex_id =  "";
													$weight = "";
													$genetic = "";
													$photo = "";
													
													echo "<div class='alert alert-success alert-dismissible'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																<strong>Thank you!</strong> Your pet successfully registered.
															</div>";
												
											}
											else
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> Error.
													</div>";
				
										}
									?>
									<form method="post" enctype="multipart/form-data">
										<div class="row gx-3 mb-3">
                                                <div class="col-md-6">
                                                    <label class="small mb-1">Pet Name</label>
                                                    <input class="form-control" type="text" name="pet_name" value="<?php echo $pet_name; ?>" placeholder="Your Pet Name" required />
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="small mb-1">Pet Type</label>
													<select name="type_id" class="form-control" required>
														<option value="">- choose type -</option>
														<?php
															$sqlType = mysqli_query($conn, "SELECT * FROM pet_type");
															while($rowType = mysqli_fetch_array($sqlType))
															{
																echo "<option value='$rowType[type_id]'>$rowType[type_name]</option>";
															}
														
														?>
													</select>
                                                </div>
										</div>
										<div class="row gx-3 mb-3">
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Age (Year)</label>
                                                    <input class="form-control" type="number" name="age_year" value="<?php echo $age_year; ?>" placeholder="Age (Year)" required />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Age (Month)</label>
                                                    <input class="form-control" type="number" name="age_month" value="<?php echo $age_month; ?>" placeholder="Age (Month)" required />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Sex</label>
													<select name="sex_id" class="form-control" required>
														<option value="">- choose sex -</option>
														<?php
															$sqlSex = mysqli_query($conn, "SELECT * FROM gender");
															while($rowSex = mysqli_fetch_array($sqlSex))
															{
																echo "<option value='$rowSex[gender_id]'>$rowSex[gender]</option>";
															}
														
														?>
													</select>
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Weight</label>
                                                    <input class="form-control" type="text" name="weight" value="<?php echo $weight; ?>" placeholder="Pet's Weight (KG)" required />
                                                </div>
										</div>
										<div class="row gx-3 mb-3">
                                                <div class="col-md-6">
													<label class="small mb-1">Genetic</label>
													<input class="form-control" type="text" name="genetic" value="<?php echo $genetic; ?>" placeholder="Genetic" required />
                                                </div>
                                                <div class="col-md-6">
													<label class="small mb-1">Photo</label>
													<input class="form-control" type="file" name="photo" value="<?php echo $photo; ?>" placeholder="Photo" required />
                                                </div>
										</div>
										<!-- Reset and Submit button-->
										<button class="btn btn-dark btn-icon-split" type="reset">
											<span class="icon text-white-50">
												<i class="fas fa-dice"></i>
											</span>
											<span class="text">Reset</span>
										</button>
										<button class="btn btn-primary btn-icon-split" type="submit" name="register">
											<span class="icon text-white-50">
												<i class="fas fa-check"></i>
											</span>
											<span class="text">Register</span>
										</button>
									</form>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>