
			  <!-- Modal -->
              <div class="modal fade" id="updateClinic<?php echo $row['username']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content" style="width:750px;">
                            <div class="modal-header">
                                <p class="modal-title text-primary"><i class='fas fa-pen'></i> Update Veterinary Clinic's Details</p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="update_clinic.php" enctype="multipart/form-data">
							<input type="hidden" class="form-control" name="username" value="<?php echo $row['username']; ?>" readonly />
                            <div class="modal-body">
								<div class="row gx-3 mb-3">
									<div class="col-md-6">
										<label class="small mb-1">Clinic Vet Name</label>
										<input class="form-control" type="text" name="clinic_name" value="<?php echo $row['clinic_name']; ?>" placeholder="Clinic Vet Name" required />
									</div>
									<div class="col-md-6">
										<label class="small mb-1">Owner Name</label>
										<input class="form-control" type="text" name="owner_name" value="<?php echo $row['owner_name']; ?>" placeholder="Owner Name" required />
									</div>
								</div>
								<div class="row gx-3 mb-3">
									<div class="col-md-3">
										<label class="small mb-1">License No.</label>
										<input class="form-control" type="text" name="license_no" value="<?php echo $row['license_no']; ?>" placeholder="License No." required />
									</div>
									<div class="col-md-3">
										<label class="small mb-1">Region</label>
										<select class="form-control" name="region_id" required>
											<option value="">- choose region -</option>
											<?php
												$sqlRegion = mysqli_query($conn, "SELECT * FROM region");
												while($rowRegion = mysqli_fetch_array($sqlRegion))
												{
													if($rowRegion['region_id'] == $row['region_id'])
														echo "<option value='$rowRegion[region_id]' selected>$rowRegion[region]</option>";
													else
														echo "<option value='$rowRegion[region_id]'>$rowRegion[region]</option>";
												}
											?>
										</select>
									</div>
									<div class="col-md-6">
										<label class="small mb-1">Clinic Picture <span class="badge badge-warning">(if necessary)</span></label>
										<input class="form-control" type="file" name="picture" />
									</div>
								</div>
								<div class="row gx-3 mb-3">
									<div class="col-md-6">
										<label class="small mb-1">Email</label>
										<input class="form-control" type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Email Address" required />
									</div>
									<div class="col-md-6">
										<label class="small mb-1">Tel. No</label>
										<input class="form-control" type="number" name="tel_no" value="<?php echo $row['tel_no']; ?>" placeholder="Tel. No" required />
									</div>
								</div>
								<div class="row gx-3 mb-3">
									<div class="col-md-6">
										<label class="small mb-1">Open Time</label>
										<input class="form-control" type="time" name="open_time" value="<?php echo $row['open_time']; ?>" placeholder="Open Time" required />
									</div>
									<div class="col-md-6">
										<label class="small mb-1">Close Time</label>
										<input class="form-control" type="time" name="close_time" value="<?php echo $row['close_time']; ?>" placeholder="Close Time" required />
									</div>
								</div>
									  
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Update</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->