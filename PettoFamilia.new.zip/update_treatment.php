<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	
	//post staff data
	$treatment_id = $_POST['treatment_id'];
	$treatment = $_POST['treatment'];
	$price = $_POST['price'];
	$description = $_POST['description'];

	
	$sql = mysqli_query($conn, "UPDATE treatment SET treatment = '$treatment',
																price = '$price',
																description = '$description'
																WHERE treatment_id = '$treatment_id'");					
																	
	header('location:manage_treatment.php');
}

?>