<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
						<small>Welcome <span class="text-primary"><?php echo $name; ?></span> to Petto Familia</small>
                    </div>
					
					<?php
		
						date_default_timezone_set("Asia/Kuala_Lumpur");
						$today = date("Y-m-d");
						
						$todayString = str_replace('-', '/', $today);
						$todayStringFormat = date('d/m/Y', strtotime($todayString));
					
						//dashboard admin
						if($_SESSION['level'] == 1)
						{
							//calculate total pet owner
							$sqlOwner = mysqli_query($conn, "SELECT * FROM owner");
							$numRowOwner = mysqli_num_rows($sqlOwner);
							
							//calculate total pet
							$sqlPet = mysqli_query($conn, "SELECT * FROM pet");
							$numRowPet = mysqli_num_rows($sqlPet);
							
							//calculate total clinic
							$sqlClinic = mysqli_query($conn, "SELECT * FROM clinic");
							$numRowClinic = mysqli_num_rows($sqlClinic);
							
							//calculate total appointment
							$sqlApp = mysqli_query($conn, "SELECT * FROM booking");
							$numRowApp = mysqli_num_rows($sqlApp);
					
							echo "<!-- Content Row -->
										<div class='row'>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-success shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-success text-uppercase mb-1'>
																	PET OWNER</div>
																<div class='h5 mb-0 font-weight-bold text-success'>$numRowOwner</div>
															</div>
															<div class='col-auto'>
																 <i class='icon icon-user-following fa-2x text-success'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-danger shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-danger text-uppercase mb-1'>
																	PET</div>
																<div class='h5 mb-0 font-weight-bold text-danger'>$numRowPet</div>
															</div>
															<div class='col-auto'>
																 <i class='icon icon-social-github fa-2x text-danger'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<!-- Earnings (Monthly) Card Example -->
											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-info shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-info text-uppercase mb-1'>Clinic
																</div>
																<div class='row no-gutters align-items-center'>
																	<div class='col-auto'>
																		<div class='h5 mb-0 mr-3 font-weight-bold text-info'>$numRowClinic</div>
																	</div>
																</div>
															</div>
															<div class='col-auto'>
																<i class='icon icon-docs fa-2x text-info'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<!-- Pending Requests Card Example -->
											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-warning shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-warning text-uppercase mb-1'>
																	Appointment</div>
																<div class='h5 mb-0 font-weight-bold text-warning'>$numRowApp</div>
															</div>
															<div class='col-auto'>
																<i class='icon icon-book-open fa-2x text-warning'></i>
															</div>
														</div>
													</div>
												</div>
											</div>
											
											
										</div>

										<!-- Content Row -->

										<div class='row'>


											<div class='col-lg-12 mb-4'>
												<!-- DataTales Example -->
												<div class='card shadow mb-4'>
													<div class='card-header py-3'>
														<h6 class='m-0 font-weight-bold text-primary'>Today's Appointment $todayStringFormat</h6>
													</div>
													<div class='card-body'>
														<div class='table-responsive'>
															<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
																<thead>
																	<tr>
																		<th>Booking#</th>
																		<th>Clinic</th>
																		<th>Date Time</th>
																		<th>Pet</th>
																		<th>Treatment</th>
																		<th>Price</th>
																		<th>Note</th>
																		<th>Status</th>
																		<th>Action</th>
																	</tr>
																</thead>
																
																<tbody>";
																	
																	
																	$sql = mysqli_query($conn, "SELECT * FROM booking WHERE booking_date = '$today'");
																	while($row = mysqli_fetch_array($sql))
																	{
																		//clinic name
																		$sqlClinic = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$row[clinic_id]'");
																		$rowClinic = mysqli_fetch_array($sqlClinic);
																		
																		//pet details
																		$sqlPet = mysqli_query($conn, "SELECT * FROM pet WHERE pet_id = '$row[pet_id]'");
																		$rowPet = mysqli_fetch_array($sqlPet);
																		
																		//slot
																		$sqlSlot = mysqli_query($conn, "SELECT * FROM slot WHERE slot_id = '$row[slot_id]'");
																		$rowSlot = mysqli_fetch_array($sqlSlot);
																		
																		//treatment
																		$sqlTreatment = mysqli_query($conn, "SELECT * FROM treatment WHERE treatment_id = '$row[treatment_id]'");
																		$rowTreatment = mysqli_fetch_array($sqlTreatment);
																		
																		//highlight booking status
																		if($row['booking_status'] == "Booked")
																			$booking_status = "<span class='badge badge-primary'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Cancelled")
																			$booking_status = "<span class='badge badge-danger'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Upcoming")
																			$booking_status = "<span class='badge badge-warning'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Completed")
																			$booking_status = "<span class='badge badge-success'>$row[booking_status]</span>";
																							
																		//cek comment
																		if($row['comment'] != NULL)
																		{
																			$comment = "<a href='#' data-toggle='modal'
																							data-target='#viewComent$row[booking_id]'>
																							<i class='fas fa-comments text-primary'></i>
																						</a>";
																		}
																		else if($row['comment'] == NULL)
																		{
																			$comment = "<span class='badge badge-warning'>- - -</span>";
																		}

																		echo "<tr>	
																				<td>$row[booking_id]</td>
																				<td>$rowClinic[clinic_name]</td>
																				<td>$row[booking_date]<br />($rowSlot[slot])</td>				
																				<td>$rowPet[pet_name]</td>
																				<td>$rowTreatment[treatment]</td>
																				<td>$rowTreatment[price]</td>
																				<td>$row[note]</td>
																				<td>$booking_status</td>
																				<td>$comment</td>
																				</tr>";
																						
																				include "modal_view_comment.php";
																	}
																	
														echo "</tbody>
															</table>
														</div>
													</div>
												</div>

											</div>
										</div>";
						}
					
						//dashboard clinic
						else if($_SESSION['level'] == 2)
						{
							
							//calculate total all appointment booked for current clinic
							$sqlApp = mysqli_query($conn, "SELECT * FROM booking WHERE clinic_id = '$_SESSION[user_id]'");
							$numRowApp = mysqli_num_rows($sqlApp);
							
							//calculate total cancelled appointment for current clinic
							$sqlCancelled = mysqli_query($conn, "SELECT * FROM booking WHERE booking_status = 'Cancelled' AND clinic_id = '$_SESSION[user_id]'");
							$numRowCancelled = mysqli_num_rows($sqlCancelled);
							
							//calculate total upcoming appointment for current clinic
							$sqlUpcoming = mysqli_query($conn, "SELECT * FROM booking WHERE booking_status = 'Upcoming' AND clinic_id = '$_SESSION[user_id]'");
							$numRowUpcoming = mysqli_num_rows($sqlUpcoming);
							
							//calculate total completed appointment for current clinic
							$sqlCompleted = mysqli_query($conn, "SELECT * FROM booking WHERE booking_status = 'Completed' AND clinic_id = '$_SESSION[user_id]'");
							$numRowCompleted = mysqli_num_rows($sqlCompleted);
					
							echo "<!-- Content Row -->
										<div class='row'>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-info shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-info text-uppercase mb-1'>
																	OVERALL APPOINTMENT</div>
																<div class='h5 mb-0 font-weight-bold text-info'>$numRowApp</div>
															</div>
															<div class='col-auto'>
																 <i class='icon icon-book-open fa-2x text-info'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-danger shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-danger text-uppercase mb-1'>
																	CANCELLED APPOINTMENT</div>
																<div class='h5 mb-0 font-weight-bold text-danger'>$numRowCancelled</div>
															</div>
															<div class='col-auto'>
																 <i class='icon icon-book-open fa-2x text-danger'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-warning shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-warning text-uppercase mb-1'>
																	UPCOMING APPOINTMENT
																</div>
																<div class='row no-gutters align-items-center'>
																	<div class='col-auto'>
																		<div class='h5 mb-0 mr-3 font-weight-bold text-warning'>$numRowUpcoming</div>
																	</div>
																</div>
															</div>
															<div class='col-auto'>
																<i class='icon icon-book-open fa-2x text-warning'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-success shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-success text-uppercase mb-1'>
																	COMPLETED APPOINTMENT</div>
																<div class='h5 mb-0 font-weight-bold text-success'>$numRowCompleted</div>
															</div>
															<div class='col-auto'>
																<i class='icon icon-book-open fa-2x text-success'></i>
															</div>
														</div>
													</div>
												</div>
											</div>
											
											
										</div>

										<!-- Content Row -->";
										
										if(isset($_POST['myselect']))
										{
											$booking_id = $_POST['booking_id'];
											$myselect = $_POST['myselect'];
											
											$setStatus = mysqli_query($conn, "UPDATE booking SET booking_status = '$myselect' WHERE booking_id = '$booking_id'");
															
											
											//vaccination function; add into vaccination reminder
											$treatment = $_POST['treatment'];
											$clinic_id = $_POST['clinic_id'];
											$owner_id =$_POST['owner_id'];
											$pet_id = $_POST['pet_id'];
											$booking_date = $_POST['booking_date'];
											
											//add reminder
											if(($treatment == "Vaccination") && ($myselect == "Completed"))
											{
												
												// Add one year to the booking date
												$expired_date = date("Y-m-d", strtotime("+1 year", strtotime($booking_date)));
												
												//cek dulu kalau dah add dalam reminder, abaikan
												$sqlCheck = mysqli_query($conn, "SELECT * FROM vaccination_reminder WHERE clinic_id = '$clinic_id'
																															AND owner_id = '$owner_id'
																															AND pet_id = '$pet_id'
																															AND expired_date = '$expired_date'");
												
												$numRowCheck = mysqli_num_rows($sqlCheck);
												/*
												echo "clinic_id: " . $clinic_id;
												echo "<br />";
												echo "owner_id: " . $owner_id;
												echo "<br />";
												echo "pet_id: " . $pet_id;
												echo "<br />";
												echo "expired_date: " . $expired_date;
												echo "<br />";
												echo "bil reminder: " . $numRowCheck;
												*/
												if($numRowCheck == 0)
												{
																									
													$addReminder = mysqli_query($conn, "INSERT INTO vaccination_reminder (clinic_id, owner_id, pet_id, vaccination_date, expired_date)
																													VALUES ('$clinic_id', '$owner_id', '$pet_id', '$booking_date', '$expired_date')");
												
												}																
											}
											//remove back reminder if clinic accidentally change booking statu other than completed
											else if(($treatment == "Vaccination") && ($myselect != "Completed"))
											{
												
												// Add one year to the booking date
												$expired_date = date("Y-m-d", strtotime("+1 year", strtotime($booking_date)));
												
												//cek dulu kalau dah add dalam reminder, boleh remove balik
												$sqlCheck = mysqli_query($conn, "SELECT * FROM vaccination_reminder WHERE clinic_id = '$clinic_id'
																															AND owner_id = '$owner_id'
																															AND pet_id = '$pet_id'
																															AND vaccination_date = '$booking_date'
																															AND expired_date = '$expired_date'");
												
												$numRowCheck = mysqli_num_rows($sqlCheck);
												
												if($numRowCheck > 0)
												{
																									
													$removeReminder = mysqli_query($conn, "DELETE FROM vaccination_reminder WHERE clinic_id = '$clinic_id'
																																	AND owner_id = '$owner_id'
																																	AND pet_id = '$pet_id'
																																	AND vaccination_date = '$booking_date'
																																	AND expired_date = '$expired_date'");
												
												}																
											}
 											/**/
											if($setStatus == true)
											{
												echo "<script>window.location = 'dashboard.php?code=displayStatus&booking_id=$booking_id';</script>";
															
											}
											
										}
										
										$code = $_GET['code'];
										if($code == "displayStatus")
										{
											$booking_id =  $_GET['booking_id'];
														
											echo "<div class='alert alert-success alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Thank you!</strong> Status for Booking ID $booking_id was updated.
													</div>";
										}
										else if($code == "comment")
										{
											$booking_id =  $_GET['booking_id'];
														
											echo "<div class='alert alert-success alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Thank you!</strong> Comment for Booking ID $booking_id was submitted.
													</div>";
										}

								echo"<div class='row'>


											<div class='col-lg-12 mb-4'>
												<!-- DataTales Example -->
												<div class='card shadow mb-4'>
													<div class='card-header py-3'>
														<h6 class='m-0 font-weight-bold text-primary'>Today's Appointment $todayStringFormat for Your Clinic</h6>
													</div>
													<div class='card-body'>
														<div class='table-responsive'>
															<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
																<thead>
																	<tr>
																		<th>Booking#</th>
																		<th>Clinic</th>
																		<th>Date Time</th>
																		<th>Pet</th>
																		<th>Treatment</th>
																		<th>Price</th>
																		<th>Note</th>
																		<th>Status</th>
																		<th>Action</th>
																	</tr>
																</thead>
																
																<tbody>";
																	
																	
																	$sql = mysqli_query($conn, "SELECT * FROM booking WHERE booking_date = '$today' AND clinic_id = '$_SESSION[user_id]'");
																	while($row = mysqli_fetch_array($sql))
																	{
																		//clinic name
																		$sqlClinic = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$row[clinic_id]'");
																		$rowClinic = mysqli_fetch_array($sqlClinic);
																		
																		//pet details
																		$sqlPet = mysqli_query($conn, "SELECT * FROM pet WHERE pet_id = '$row[pet_id]'");
																		$rowPet = mysqli_fetch_array($sqlPet);
																		
																		//slot
																		$sqlSlot = mysqli_query($conn, "SELECT * FROM slot WHERE slot_id = '$row[slot_id]'");
																		$rowSlot = mysqli_fetch_array($sqlSlot);
																		
																		//treatment
																		$sqlTreatment = mysqli_query($conn, "SELECT * FROM treatment WHERE treatment_id = '$row[treatment_id]'");
																		$rowTreatment = mysqli_fetch_array($sqlTreatment);
																		
																		
																		$dateString = str_replace('-', '/', $row['booking_date']);
																		$dateStringFormat = date('d/m/Y', strtotime($dateString));
																		
																		$url = "dashboard";
																		
																		/*
																		//highlight booking status
																		if($row['booking_status'] == "Booked")
																			$booking_status = "<span class='badge badge-primary'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Cancelled")
																			$booking_status = "<span class='badge badge-danger'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Done")
																			$booking_status = "<span class='badge badge-success'>$row[booking_status]</span>";
																		*/	
																		
																		echo "<tr>	
																				<td>$row[booking_id]</td>
																				<td>$rowClinic[clinic_name]</td>
																				<td>$dateStringFormat<br />($rowSlot[slot])</td>				
																				<td>$rowPet[pet_name]</td>
																				<td>$rowTreatment[treatment]</td>
																				<td>$rowTreatment[price]</td>
																				<td>$row[note]</td>
																				<td>";
											
											
																					echo  "<form method='post'>
																									<input type='hidden' name='booking_id' value='$row[booking_id]'>
																									<input type='hidden' name='treatment' value='$rowTreatment[treatment]'>
																									<input type='hidden' name='clinic_id' value='$row[clinic_id]'>
																									<input type='hidden' name='owner_id' value='$row[owner_id]'>
																									<input type='hidden' name='pet_id' value='$row[pet_id]'>
																									<input type='hidden' name='booking_date' value='$row[booking_date]'>
																										<select name='myselect' class='form-control' onchange='javascript: submit()'>";
																										$getStatus = mysqli_query($conn, "SELECT * FROM booking_status");
																										while($rowStatus = mysqli_fetch_array($getStatus))
																										{
																											if($rowStatus['status'] == $row['booking_status'])
																												echo "<option selected>$rowStatus[status]</option>";
																											else
																												echo "<option>$rowStatus[status]</option>";
																										}
																									echo"</select>
																									</form>";
																				
																			
																			echo"</td>
																				<td>
																					<a href='#' data-toggle='modal'
																						data-target='#addComent$row[booking_id]'>
																						<i class='fas fa-paper-plane text-primary'></i>
																					</a>
																				</td>
																				</tr>";
																	
																		include "modal_add_comment.php";
																	}
																	
														echo "</tbody>
															</table>
														</div>
													</div>
												</div>

											</div>
										</div>";
						}
						
						//dashboard pet owner
						else if($_SESSION['level'] == 3)
						{
							
							//calculate total all appointment booked for current pet owner
							$sqlApp = mysqli_query($conn, "SELECT * FROM booking WHERE owner_id = '$_SESSION[user_id]'");
							$numRowApp = mysqli_num_rows($sqlApp);
							
							//calculate total cancelled appointment for current pet owner
							$sqlCancelled = mysqli_query($conn, "SELECT * FROM booking WHERE booking_status = 'Cancelled' AND owner_id = '$_SESSION[user_id]'");
							$numRowCancelled = mysqli_num_rows($sqlCancelled);
							
							//calculate total upcoming appointment for current pet owner
							$sqlUpcoming = mysqli_query($conn, "SELECT * FROM booking WHERE booking_status = 'Upcoming' AND owner_id = '$_SESSION[user_id]'");
							$numRowUpcoming = mysqli_num_rows($sqlUpcoming);
							
							//calculate total completed appointment for current pet owner
							$sqlCompleted = mysqli_query($conn, "SELECT * FROM booking WHERE booking_status = 'Completed' AND owner_id = '$_SESSION[user_id]'");
							$numRowCompleted = mysqli_num_rows($sqlCompleted);
					
							echo "<!-- Content Row -->
										<div class='row'>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-info shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-info text-uppercase mb-1'>
																	OVERALL APPOINTMENT</div>
																<div class='h5 mb-0 font-weight-bold text-info'>$numRowApp</div>
															</div>
															<div class='col-auto'>
																 <i class='icon icon-book-open fa-2x text-info'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-danger shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-danger text-uppercase mb-1'>
																	CANCELLED APPOINTMENT</div>
																<div class='h5 mb-0 font-weight-bold text-danger'>$numRowCancelled</div>
															</div>
															<div class='col-auto'>
																 <i class='icon icon-book-open fa-2x text-danger'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-warning shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-warning text-uppercase mb-1'>
																	UPCOMING APPOINTMENT
																</div>
																<div class='row no-gutters align-items-center'>
																	<div class='col-auto'>
																		<div class='h5 mb-0 mr-3 font-weight-bold text-warning'>$numRowUpcoming</div>
																	</div>
																</div>
															</div>
															<div class='col-auto'>
																<i class='icon icon-book-open fa-2x text-warning'></i>
															</div>
														</div>
													</div>
												</div>
											</div>

											<div class='col-xl-3 col-md-6 mb-4'>
												<div class='card border-left-success shadow h-100 py-2'>
													<div class='card-body'>
														<div class='row no-gutters align-items-center'>
															<div class='col mr-2'>
																<div class='text-xs font-weight-bold text-success text-uppercase mb-1'>
																	COMPLETED APPOINTMENT</div>
																<div class='h5 mb-0 font-weight-bold text-success'>$numRowCompleted</div>
															</div>
															<div class='col-auto'>
																<i class='icon icon-book-open fa-2x text-success'></i>
															</div>
														</div>
													</div>
												</div>
											</div>
											
											
										</div>

										<!-- Content Row -->

										<div class='row'>


											<div class='col-lg-12 mb-4'>
												<!-- DataTales Example -->
												<div class='card shadow mb-4'>
													<div class='card-header py-3'>
														<h6 class='m-0 font-weight-bold text-primary'>Today's Appointment $todayStringFormat for Your Pet</h6>
													</div>
													<div class='card-body'>
														<div class='table-responsive'>
															<table class='table table-bordered' id='dataTable' width='100%' cellspacing='0'>
																<thead>
																	<tr>
																		<th>Booking#</th>
																		<th>Clinic</th>
																		<th>Date Time</th>
																		<th>Pet</th>
																		<th>Treatment</th>
																		<th>Price</th>
																		<th>Note</th>
																		<th>Status</th>
																		<th>Comment</th>
																	</tr>
																</thead>
																
																<tbody>";
																	
																	
																	$sql = mysqli_query($conn, "SELECT * FROM booking WHERE booking_date = '$today' AND owner_id = '$_SESSION[user_id]'");
																	while($row = mysqli_fetch_array($sql))
																	{
																		//clinic name
																		$sqlClinic = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$row[clinic_id]'");
																		$rowClinic = mysqli_fetch_array($sqlClinic);
																		
																		//pet details
																		$sqlPet = mysqli_query($conn, "SELECT * FROM pet WHERE pet_id = '$row[pet_id]'");
																		$rowPet = mysqli_fetch_array($sqlPet);
																		
																		//slot
																		$sqlSlot = mysqli_query($conn, "SELECT * FROM slot WHERE slot_id = '$row[slot_id]'");
																		$rowSlot = mysqli_fetch_array($sqlSlot);
																		
																		//treatment
																		$sqlTreatment = mysqli_query($conn, "SELECT * FROM treatment WHERE treatment_id = '$row[treatment_id]'");
																		$rowTreatment = mysqli_fetch_array($sqlTreatment);
																		
																		//highlight booking status
																		if($row['booking_status'] == "Booked")
																			$booking_status = "<span class='badge badge-primary'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Cancelled")
																			$booking_status = "<span class='badge badge-danger'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Upcoming")
																			$booking_status = "<span class='badge badge-warning'>$row[booking_status]</span>";
																		else if($row['booking_status'] == "Completed")
																			$booking_status = "<span class='badge badge-success'>$row[booking_status]</span>";
																		
																		//cek comment
																		if($row['comment'] != NULL)
																		{
																			$comment = "<a href='#' data-toggle='modal'
																							data-target='#viewComent$row[booking_id]'>
																							<i class='fas fa-comments text-primary'></i>
																						</a>";
																		}
																		else if($row['comment'] == NULL)
																		{
																			$comment = "<span class='badge badge-warning'>- - -</span>";
																		}
																			
																		
																		echo "<tr>	
																				<td>$row[booking_id]</td>
																				<td>$rowClinic[clinic_name]</td>
																				<td>$row[booking_date] ($rowSlot[slot])</td>				
																				<td>$rowPet[pet_name]</td>
																				<td>$rowTreatment[treatment]</td>
																				<td>$rowTreatment[price]</td>
																				<td>$row[note]</td>
																				<td>$booking_status</td>
																				<td>$comment</td>
																				</tr>";
																	
																		include "modal_view_comment.php";
																	}
																	
														echo "</tbody>
															</table>
														</div>
													</div>
												</div>

											</div>
										</div>";
						}
					
					
					?>

                    
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>