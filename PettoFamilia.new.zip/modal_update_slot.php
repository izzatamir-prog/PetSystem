
			  <!-- Modal -->
              <div class="modal fade" id="updateSlot<?php echo $row['clinic_slot_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p class="modal-title text-primary"><i class='fas fa-pen'></i> Update Time Slot</p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="update_slot.php" enctype="multipart/form-data">
							<input type="text" class="form-control" name="clinic_slot_id" value="<?php echo $row['clinic_slot_id']; ?>" readonly />
                            <div class="modal-body">
								<div class="row gx-3 mb-3">
									<div class="col-md-6">
										<label class="small mb-1">Slot</label>
										<select class="form-control" name="slot_id" required>
											<option value="">- choose slot -</option>
											<?php
												$sqlSlot = mysqli_query($conn, "SELECT * FROM slot");
												while($rowSlot = mysqli_fetch_array($sqlSlot))
												{
													if($rowSlot['slot_id'] == $row['slot_id'])
														echo "<option value='$rowSlot[slot_id]' selected>$rowSlot[slot]</option>";
													else
														echo "<option value='$rowSlot[slot_id]'>$rowSlot[slot]</option>";
												}
											?>
										</select>
									</div>
								</div>
								
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Update</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->