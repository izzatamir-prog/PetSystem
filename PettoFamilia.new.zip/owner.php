<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                
                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Pet Owner</h1>
						<small>Manage Pet Owner Account</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">List of Pet Owner Account</h6>
								</div>
								<div class="card-body">
									<?php
		
										$act = $_GET['act'];
										
										
										if ($act=='activate')
										{
											$username =  $_GET['username'];
											
											$sql = mysqli_query($conn, "UPDATE login SET status = 'Active' WHERE user_id = '$username'");
											
											if($sql == true)
											{
												echo "<div class='alert alert-success alert-dismissible'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
															<strong>Thank you!</strong> Owner account successfully activated.
															</div>";
											}
												
										}
										else if ($act=='deactivate')
										{
											$username =  $_GET['username'];
											
											$sql = mysqli_query($conn, "UPDATE login SET status = 'Inactive' WHERE user_id = '$username'");
											
											if($sql == true)
											{
												echo "<div class='alert alert-danger alert-dismissible'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
															<strong>Thank you!</strong> Owner account successfully deactivated.
														</div>";
											}
												
										}
								?>
									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>Owner#</th>
													<th>Name</th>
													<th>Email</th>
													<th>Tel</th>
													<th>Status</th>
												</tr>
											</thead>
											<tfoot>
												<tr>
													<th>Owner#</th>
													<th>Name</th>
													<th>Email</th>
													<th>Tel</th>
													<th>Status</th>
												</tr>
											</tfoot>
											<tbody>
												<?php
												
												$sql = mysqli_query($conn, "SELECT * FROM login l, owner o
																									WHERE l.user_id = o.username
																									AND l.level = 3");
												while($row = mysqli_fetch_array($sql))
												{
													
													// if status active, admin can click to deactivate cust acc
													if($row['status'] == "Active")
													{
														$displaystatus = "<a href='owner.php?act=deactivate&username=$row[username]'
																			data-toggle='tooltip' data-placement='right' title='Deactivate'
																			onclick=\"return confirm('Are you sure you want to deactivated owner $row[name] account?');\">
																				<button class='btn btn-success btn-sm'>
																					$row[status]
																				</button>
																			</a>";
																			
														
													}
													// if inactive or tersilap klik inactivte, can click again to reactivated
													else if($row['status'] == "Inactive")
													{
														$displaystatus = "<a href='owner.php?act=activate&username=$row[username]'
																			data-toggle='tooltip' data-placement='right' title='Activate'>
																				<button class='btn btn-danger btn-sm'>
																					$row[status]
																				</button>
																			</a>";
													}
							
													echo "<tr>	
															<td>$row[username]</td>
															<td>$row[name]</td>
															<td>$row[email]</td>
															<td>$row[tel]</td>
															<td>$displaystatus</td>
															</tr>";
												
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>