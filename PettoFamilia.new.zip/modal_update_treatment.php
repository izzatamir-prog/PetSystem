
			  <!-- Modal -->
              <div class="modal fade" id="updateTreatment<?php echo $row['treatment_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p class="modal-title"><i class="fas fa-pen text-primary"></i> Update Treatment Details</p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="update_treatment.php" enctype="multipart/form-data">
							<input class="form-control" type="hidden" name="treatment_id" value="<?php echo $row['treatment_id']; ?>" placeholder="Treatment ID" readonly />
									
                            <div class="modal-body">
								<div class="row gx-3 mb-3">
									 <div class="col-md-6">
										<label class="small mb-1">Treatment</label>
										<input class="form-control" type="text" name="treatment" value="<?php echo $row['treatment']; ?>" placeholder="Treatment Name" required />
									 </div>
									 <div class="col-md-6">
										<label class="small mb-1">Price (RM)</label>
										<input class="form-control" type="text" name="price" value="<?php echo $row['price']; ?>" placeholder="Price (RM)" required />
									 </div>
								</div>
								<div class="row gx-3 mb-3">
									 <div class="col-md-12">
										<label class="small mb-1">Description</label>
										<textarea class="form-control" name="description" rows="5" placeholder="Write treatment description here..." required ><?php echo $row['description']; ?></textarea>
									 </div>
								</div>
									  
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Update</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->