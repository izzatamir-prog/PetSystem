-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2024 at 12:15 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_petto_familia_new`
--
CREATE DATABASE IF NOT EXISTS `db_petto_familia_new` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `db_petto_familia_new`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(55) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(55) NOT NULL,
  `phone` varchar(55) NOT NULL,
  `gender_id` char(11) NOT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `name`, `email`, `phone`, `gender_id`, `photo`) VALUES
('admin', 'izzat amir', 'izzatamit@gmail.com', '0192218615', 'M', '03ntfattah_1496456624.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` varchar(55) NOT NULL,
  `clinic_id` varchar(55) NOT NULL,
  `booking_date` date NOT NULL,
  `slot_id` int(11) NOT NULL,
  `pet_id` varchar(55) NOT NULL,
  `treatment_id` varchar(55) NOT NULL,
  `note` text NOT NULL,
  `booking_status` varchar(55) NOT NULL DEFAULT 'Booked',
  `comment` text NOT NULL,
  `owner_id` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `clinic_id`, `booking_date`, `slot_id`, `pet_id`, `treatment_id`, `note`, `booking_status`, `comment`, `owner_id`) VALUES
('BOOKING00001', 'abuvet01', '2024-06-08', 39, '1', 'TABUVET01VNNT6', 'need to be vaccined. thank you.', 'Completed', 'Your pet look good and happy now. Have a nice weekend and please come again. Thank you. :)', 'ahmad'),
('BOOKING00002', 'apizvet01', '2024-06-09', 6, '2', 'TAPIZVET0185XMB', 'my pet seem not feeling well.', 'Booked', '', 'ahmad'),
('BOOKING00003', 'abuvet01', '2024-06-08', 36, '2', 'TABUVET01VNNT6', 'Come for vaccination', 'Completed', '', 'ahmad');

-- --------------------------------------------------------

--
-- Table structure for table `booking_status`
--

CREATE TABLE `booking_status` (
  `status_id` int(11) NOT NULL,
  `status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking_status`
--

INSERT INTO `booking_status` (`status_id`, `status`) VALUES
(1, 'Booked'),
(2, 'Cancelled'),
(3, 'Upcoming'),
(4, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `clinic`
--

CREATE TABLE `clinic` (
  `username` varchar(55) NOT NULL,
  `clinic_name` varchar(100) NOT NULL,
  `license_no` varchar(55) NOT NULL,
  `owner_name` varchar(100) NOT NULL,
  `region_id` int(11) NOT NULL,
  `email` varchar(55) NOT NULL,
  `tel_no` varchar(55) NOT NULL,
  `open_time` time NOT NULL,
  `close_time` time NOT NULL,
  `picture` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinic`
--

INSERT INTO `clinic` (`username`, `clinic_name`, `license_no`, `owner_name`, `region_id`, `email`, `tel_no`, `open_time`, `close_time`, `picture`) VALUES
('abuvet01', 'ABU VET. CLINIC', 'PVX125', 'Abu Ubai', 1, 'abuvet@gmail.com', '022022202', '09:00:00', '18:00:00', 'istockphoto-1203744384-612x612.jpg'),
('apizvet01', 'APIZ VET. CLINIC', '', 'Apiz Dorsata', 1, 'apizvet@gmail.com', '033033303', '10:00:00', '17:30:00', 'veterinarian-doctor-with-dog-in-vet-clinic-medicine-and-vet-care-concept-illustration-vector.jpg'),
('izzatvet', 'Izzat Vet', 'PVD134', 'Izzat Amir', 1, 'izzatvet@gmail.com', '0188088808', '09:00:00', '21:00:00', 'Screenshot 2024-06-27 171448.png'),
('jamilahvet', 'JAMILAH VET CLINIC', '', 'Nurul Jamilah', 3, 'jamilahvet@gmail.com', '044044404', '09:30:00', '18:00:00', 'Screenshot 2024-05-19 174854.png'),
('vivavet', 'VIVA VET. CLINIC', '', 'Nur Viva Diva', 2, 'vivavet@gmail.com', '055055505', '08:30:00', '17:30:00', 'istockphoto-1343389490-612x612.jpg'),
('zafierahvet', 'ZAFIERAH VET. CLINIC', '', 'Siti Zafierah', 2, 'zafierahvet@gmail.com', '066066606', '05:16:00', '17:16:00', 'istockphoto-1203744384-612x612.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_slot`
--

CREATE TABLE `clinic_slot` (
  `clinic_slot_id` int(11) NOT NULL,
  `slot_id` int(11) NOT NULL,
  `clinic_id` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinic_slot`
--

INSERT INTO `clinic_slot` (`clinic_slot_id`, `slot_id`, `clinic_id`) VALUES
(2, 10, 'abuvet01'),
(3, 12, 'abuvet01'),
(4, 14, 'abuvet01'),
(5, 16, 'abuvet01'),
(6, 18, 'abuvet01'),
(7, 20, 'abuvet01'),
(8, 22, 'abuvet01'),
(9, 24, 'abuvet01'),
(10, 26, 'abuvet01'),
(11, 28, 'abuvet01'),
(12, 30, 'abuvet01'),
(13, 32, 'abuvet01'),
(14, 34, 'abuvet01'),
(15, 36, 'abuvet01'),
(16, 6, 'apizvet01'),
(17, 10, 'apizvet01'),
(18, 14, 'apizvet01'),
(19, 18, 'apizvet01'),
(20, 22, 'apizvet01'),
(21, 26, 'apizvet01'),
(22, 30, 'apizvet01'),
(23, 34, 'apizvet01'),
(24, 37, 'apizvet01'),
(25, 43, 'apizvet01'),
(26, 46, 'apizvet01'),
(27, 49, 'apizvet01'),
(28, 32, 'abuvet01'),
(29, 36, 'abuvet01'),
(30, 39, 'abuvet01'),
(31, 45, 'abuvet01'),
(32, 48, 'abuvet01'),
(33, 51, 'abuvet01');

-- --------------------------------------------------------

--
-- Table structure for table `clinic_staff`
--

CREATE TABLE `clinic_staff` (
  `staff_id` varchar(55) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(55) NOT NULL,
  `phone_no` varchar(55) NOT NULL,
  `gender_id` char(11) NOT NULL,
  `experience` int(11) NOT NULL,
  `photo` text NOT NULL,
  `clinic_id` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clinic_staff`
--

INSERT INTO `clinic_staff` (`staff_id`, `name`, `email`, `phone_no`, `gender_id`, `experience`, `photo`, `clinic_id`) VALUES
('fattah', 'Fattah Amin', 'fattah@gmail.com', '0177077707', 'M', 7, '03ntfattah_1496456624.jpg', 'abuvet01'),
('neelofa', 'Nurul Neelofa', 'neelofa@gmail.com', '0155055505', 'F', 5, 'neelofa-1.png', 'abuvet01');

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `gender_id` char(11) NOT NULL,
  `gender` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gender`
--

INSERT INTO `gender` (`gender_id`, `gender`) VALUES
('F', 'Female'),
('M', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `level` int(11) NOT NULL,
  `status` varchar(55) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `password`, `level`, `status`) VALUES
('abuvet01', 'abuvet01', 2, 'Active'),
('admin', 'admin', 1, 'Active'),
('ahmad', 'ahmad', 3, 'Active'),
('apizvet01', 'apizvet01', 2, 'Active'),
('datored', 'datored', 3, 'Active'),
('fattah', 'fattah', 4, 'Active'),
('fazura', 'fazura', 3, 'Inactive'),
('izzatvet', 'izzatvet', 2, 'Active'),
('jamilahvet', 'jamilahvet', 2, 'Active'),
('neelofa', 'neelofa', 4, 'Active'),
('suhaila', 'suhaila', 3, 'Active'),
('vivavet', 'vivavet', 2, 'Active'),
('zafierahvet', 'zafierahvet', 2, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `owner`
--

CREATE TABLE `owner` (
  `username` varchar(55) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(55) NOT NULL,
  `tel` varchar(55) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender_id` char(11) DEFAULT NULL,
  `photo` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `owner`
--

INSERT INTO `owner` (`username`, `name`, `email`, `tel`, `dob`, `gender_id`, `photo`) VALUES
('ahmad', 'Ahmad Fattah', 'amadhafiz@gmail.com', '0177077707', '1988-12-30', 'M', 'face13.jpg'),
('datored', 'Dato Red', 'datored@gmail.com', '0188088808', NULL, NULL, 'avatar.jpg'),
('fazura', 'Puan Fazura', 'fazura@gmail.com', '0133033303', NULL, NULL, 'avatar.jpg'),
('suhaila', 'Puan Suhaila', 'suhaila@gmail.com', '0188088808', NULL, NULL, 'avatar.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pet`
--

CREATE TABLE `pet` (
  `pet_id` int(11) NOT NULL,
  `pet_name` varchar(55) NOT NULL,
  `type_id` int(11) NOT NULL,
  `age_year` int(11) NOT NULL,
  `age_month` int(11) NOT NULL,
  `sex_id` char(11) NOT NULL,
  `weight` decimal(11,2) NOT NULL,
  `genetic` varchar(100) NOT NULL,
  `photo` text NOT NULL,
  `owner_id` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pet`
--

INSERT INTO `pet` (`pet_id`, `pet_name`, `type_id`, `age_year`, `age_month`, `sex_id`, `weight`, `genetic`, `photo`, `owner_id`) VALUES
(1, 'Oyen', 2, 2, 5, 'M', '4.50', 'Baka Kampung', '1389788.jpg', 'ahmad'),
(2, 'Oksana Susoeva', 2, 0, 5, 'F', '2.00', 'Short Hair British', 'White-British-Shorthair_OksanaSusoeva-Shutterstock.jpg', 'ahmad');

-- --------------------------------------------------------

--
-- Table structure for table `pet_type`
--

CREATE TABLE `pet_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pet_type`
--

INSERT INTO `pet_type` (`type_id`, `type_name`) VALUES
(1, 'Dog'),
(2, 'Cat'),
(3, 'Bird'),
(4, 'Fish'),
(5, 'Rodent'),
(6, 'Reptile'),
(7, 'Amphibian'),
(8, 'Arthropod'),
(9, 'Small Mammal'),
(10, 'Exotic');

-- --------------------------------------------------------

--
-- Table structure for table `region`
--

CREATE TABLE `region` (
  `region_id` int(11) NOT NULL,
  `region` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `region`
--

INSERT INTO `region` (`region_id`, `region`) VALUES
(1, 'Kajang'),
(2, 'Bangi'),
(3, 'Semenyih');

-- --------------------------------------------------------

--
-- Table structure for table `slot`
--

CREATE TABLE `slot` (
  `slot_id` int(11) NOT NULL,
  `slot` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slot`
--

INSERT INTO `slot` (`slot_id`, `slot`) VALUES
(6, '9:00 AM'),
(7, '9:15 AM'),
(8, '9:30 AM'),
(9, '9:45 AM'),
(10, '10:00 AM'),
(11, '10:15 AM'),
(12, '10:30 AM'),
(13, '10:45 AM'),
(14, '11:00 AM'),
(15, '11:15 AM'),
(16, '11:30 AM'),
(17, '11:45 AM'),
(18, '12:00 PM'),
(19, '12:15 PM'),
(20, '12:30 PM'),
(21, '12:45 PM'),
(22, '2:00 PM'),
(23, '2:15 PM'),
(24, '2:30 PM'),
(25, '2:45 PM'),
(26, '3:00 PM'),
(27, '3:15 PM'),
(28, '3:30 PM'),
(29, '3:45 PM'),
(30, '4:00 PM'),
(31, '4:15 PM'),
(32, '4:30 PM'),
(33, '4:45 PM'),
(34, '5:00 PM'),
(35, '5:15 PM'),
(36, '5:30 PM'),
(37, '6:00 PM'),
(38, '6:15 PM'),
(39, '6:30 PM'),
(40, '7:00 PM'),
(41, '7:15 PM'),
(42, '7:30 PM'),
(43, '8:00 PM'),
(44, '8:15 PM'),
(45, '8:30 PM'),
(46, '9:00 PM'),
(47, '9:15 PM'),
(48, '9:30 PM'),
(49, '10:00 PM'),
(50, '10:15 PM'),
(51, '10:30 PM');

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `treatment_id` varchar(55) NOT NULL,
  `treatment` varchar(55) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `description` text NOT NULL,
  `clinic_id` varchar(55) NOT NULL,
  `comment` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`treatment_id`, `treatment`, `price`, `description`, `clinic_id`, `comment`) VALUES
('TABUVET01VNNT6', 'Vaccination', '58.00', 'some desc of Vaccination by ABUVET here...', 'abuvet01', NULL),
('TAPIZVET011P35K', 'Vaccination', '55.00', 'some desc of Vaccination by APIZVET here...', 'apizvet01', NULL),
('TAPIZVET011R1NX', 'Environmental Management', '79.00', 'some desc of Environmental Management by APIZVET here... ', 'apizvet01', NULL),
('TAPIZVET013AYAL', 'Dental Care', '150.00', 'some desc of Dental Care by APIZVET here...', 'apizvet01', NULL),
('TAPIZVET0185XMB', 'Nutrition', '45.00', 'some desc of Nutrition by APIZVET here...', 'apizvet01', NULL),
('TAPIZVET01BIF6G', 'Parasite Control', '75.00', 'some desc of Parasite Control by APIZVET here...', 'apizvet01', NULL),
('TAPIZVET01BZZIL', 'Behavioral Modification', '88.00', 'some desc of Behavioral Modification by APIZVET here...', 'apizvet01', NULL),
('TAPIZVET01F4OCY', 'Regular Check-ups', '39.00', 'some desc of Regular Check-ups by APIZVET here...', 'apizvet01', NULL),
('TAPIZVET01N8U2S', 'Grooming', '99.00', 'some desc of Grooming by APIZVET here... ', 'apizvet01', NULL),
('TAPIZVET01VL2F2', 'Medication', '35.00', 'some desc of Medication by APIZVET here...', 'apizvet01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `vaccination_reminder`
--

CREATE TABLE `vaccination_reminder` (
  `vaccination_id` int(11) NOT NULL,
  `clinic_id` varchar(55) NOT NULL,
  `owner_id` varchar(55) NOT NULL,
  `pet_id` int(11) NOT NULL,
  `vaccination_date` date NOT NULL,
  `expired_date` date NOT NULL,
  `status` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vaccination_reminder`
--

INSERT INTO `vaccination_reminder` (`vaccination_id`, `clinic_id`, `owner_id`, `pet_id`, `vaccination_date`, `expired_date`, `status`) VALUES
(10, 'abuvet01', 'ahmad', 1, '2024-06-08', '2025-06-08', 'sent'),
(11, 'abuvet01', 'ahmad', 2, '2024-06-08', '2025-06-08', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `booking_status`
--
ALTER TABLE `booking_status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `clinic`
--
ALTER TABLE `clinic`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `clinic_slot`
--
ALTER TABLE `clinic_slot`
  ADD PRIMARY KEY (`clinic_slot_id`);

--
-- Indexes for table `clinic_staff`
--
ALTER TABLE `clinic_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`gender_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `owner`
--
ALTER TABLE `owner`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pet`
--
ALTER TABLE `pet`
  ADD PRIMARY KEY (`pet_id`);

--
-- Indexes for table `pet_type`
--
ALTER TABLE `pet_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `region`
--
ALTER TABLE `region`
  ADD PRIMARY KEY (`region_id`);

--
-- Indexes for table `slot`
--
ALTER TABLE `slot`
  ADD PRIMARY KEY (`slot_id`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`treatment_id`);

--
-- Indexes for table `vaccination_reminder`
--
ALTER TABLE `vaccination_reminder`
  ADD PRIMARY KEY (`vaccination_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking_status`
--
ALTER TABLE `booking_status`
  MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `clinic_slot`
--
ALTER TABLE `clinic_slot`
  MODIFY `clinic_slot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `pet`
--
ALTER TABLE `pet`
  MODIFY `pet_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pet_type`
--
ALTER TABLE `pet_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `region`
--
ALTER TABLE `region`
  MODIFY `region_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vaccination_reminder`
--
ALTER TABLE `vaccination_reminder`
  MODIFY `vaccination_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
