
			  <!-- Modal -->
              <div class="modal fade" id="updateStaff<?php echo $row['staff_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p class="modal-title"><i class="mdi mdi-lead-pencil text-success"></i> Update Staff Details</p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="update_staff.php" enctype="multipart/form-data">
                            <div class="modal-body">
								<div class="row gx-3 mb-3">
									 <div class="col-md-6">
										<label class="small mb-1">Staff ID</label>
										<input class="form-control" type="text" name="staff_id" value="<?php echo $row['staff_id']; ?>" placeholder="Staff ID" readonly />
									 </div>
									 <div class="col-md-6">
										<label class="small mb-1">Name</label>
										<input class="form-control" type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Staff Name" required />
									 </div>
								</div>
								<div class="row gx-3 mb-3">
									 <div class="col-md-2">
										<label class="small mb-1">Experience</label>
										<input class="form-control" type="number" name="experience" value="<?php echo $row['experience']; ?>" placeholder="Year of Experience" required />
									 </div>
									<div class="col-md-4">
										<label class="small mb-1">Phone No.</label>
										<input class="form-control" type="text" name="phone_no" value="<?php echo $row['phone_no']; ?>" placeholder="Phone No." required />
									</div>
									<div class="col-md-6">
										<label class="small mb-1">Gender</label>
										<select class="form-control" name="gender_id" required>
											<option value="">- choose gender -</option>
											<?php
												$sqlGender = mysqli_query($conn, "SELECT * FROM gender");
												while($rowGender = mysqli_fetch_array($sqlGender))
												{
													if($rowGender['gender_id'] == $row['gender_id'])
														echo "<option value='$rowGender[gender_id]' selected>$rowGender[gender]</option>";
													else
														echo "<option value='$rowGender[gender_id]'>$rowGender[gender]</option>";
												}
											?>
										</select>
									</div>
								</div>
								<div class="row gx-3 mb-3">
									 <div class="col-md-6">
										<label class="small mb-1">Email</label>
										<input class="form-control" type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Staff Email" required />
									 </div>
									<div class="col-md-6">
										<label class="small mb-1">New Photo <span class="badge badge-warning">(if necessary)</span></label>
										<input class="form-control" type="file" name="photo" />
									</div>
								</div>
									  
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Update</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->