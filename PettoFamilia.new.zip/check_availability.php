<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
select option:disabled {
            color: red; /* Change this to your desired color */
            background-color: lightgray; /* Optional: Change the background color too */
}
.custom-radio-image {
  display: none;
}

.radio-image-label {
  cursor: pointer;
  border: 4px solid transparent;
  display: inline-block;
  margin: 5px;
  border-radius: 8px; /* Add border radius for rounded corners */
  transition: border-color 0.3s, box-shadow 0.3s; /* Add transition for smooth effect */
}

.radio-image-label img {
  max-width: 300px;
  max-height: 300px;
  display: block; /* Ensure the image is displayed as block element */
  border-radius: 8px; /* Match border radius with label */
}

.custom-radio-image:checked + .radio-image-label {
  border-color: #e74a3b; /* Set border color to red */
  box-shadow: 0 0 10px rgba(0, 123, 255, 0.5); /* Add box shadow for clear selection */
}

</style>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Book Treatment</h1>
						<small>Check Availability &amp; Book Treatment</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">

                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Check Treatment Availability for Veterinary Clinic <?php echo $_GET['clinic_name']; ?></h6>
								</div>
								<div class="card-body">
								<?php
				  
									date_default_timezone_set("Asia/Kuala_Lumpur");
									$today = date("Y-m-d");
									$tomorrow = date('Y-m-d', strtotime("+1 day"));
									
									$currentTime = date("h:i A");
									
									$display = "no";
									
									//initialize button
									$showProceedBtn = "yes";
									$showSlotChoice = "no";
									$showCheckBtn = "no";
								
									if (isset($_POST['submit']))
									{
										$showSlotChoice = "yes";
										
										$booking_date = $_POST['booking_date'];
										$slot_id = $_POST['slot_id'];
										$clinic_id = $_POST['clinic_id'];
										
										$slot_explode = explode('|', $slot_id);
										$slot_id = $slot_explode[0];
										$slot = $slot_explode[1];
										
										//get clinic name
										$sqlClinic = mysqli_query($conn, "SELECT * FROM clinic WHERE clinic_id = '$clinic_id'");
										$rowClinic = mysqli_fetch_array($sqlClinic);
										$clinic = $rowClinic['clinic_name'];
										
										
														
										//cek dahulu pilihan date & time. jika pilihan masa dah berlalu. display alert.
										if(($booking_date == $today) && (strtotime($currentTime) > strtotime($slot)))
										{
											echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> Time slot $slot for today already pass.
													</div>";
										}
										else
										{
											$sqlCheck = mysqli_query($conn, "SELECT * FROM booking
																				WHERE booking_date = '$booking_date'
																				AND slot_id = '$slot_id'
																				AND clinic_id = '$clinic_id'
																				AND booking_status = 'Booked'");
										
										
											$numRowCheck = mysqli_fetch_array($sqlCheck);
											
											if($numRowCheck > 0)
											{
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> Your choice for Clinic $clinic, Slot $slot $booking_date already booking by other pet owner.
													</div>";
											}
											else
											{
												$display = "yes";
												//$booking_id = $booking_id;
												$booking_date = $booking_date;
												$slot_id = $slot_id;
												$slot = $slot;
												$clinic_id = $clinic_id;
												$clinic = $clinic;
												$staff = $staff;
												
												echo "<div class='alert alert-success alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Thank you!</strong> Your choice is available. Proceed with the confirmation form below.
													</div>";
											}
										}
											
									}
									if (isset($_POST['proceed']))
									{
										$showProceedBtn = "no";
										$showCheckBtn = "yes";
										$showSlotChoice = "yes";
										$booking_date = $_POST['booking_date'];
									}
									
							  ?>
									<form method="post">
									<input type="hidden" class="form-control" name="clinic_id" value="<?php echo $_GET['clinic_id']; ?>" readonly />
										
										<div class="row gx-3 mb-3">
                                                <div class="col-md-6">
                                                    <label class="small mb-1">Booking Date</label>
													<input type="date" min="<?php echo $today; ?>" class="form-control" name="booking_date" value="<?php echo $booking_date; ?>" placeholder="Booking Date" required />
												</div>
										</div>
										<?php
										
											//display slot based on date selection
											if($showSlotChoice == "yes")
											{
												echo "<div class='row gx-3 mb-3'>
															<div class='col-md-6'>
																<label class='small mb-1'>Time Slot</label>
																 <select class='form-control' name='slot_id' required />
																	<option value=''>- choose time slot -</option>";
																	
																		$sqlTS = mysqli_query($conn, "SELECT * FROM clinic_slot cs, slot s
																													WHERE cs.slot_id = s.slot_id
																													AND cs.clinic_id = '$_GET[clinic_id]'");
																		while($rowTS = mysqli_fetch_array($sqlTS))
																		{
																			//cek slot based on booking Date
																			$sqlCheckSlot = mysqli_query($conn, "SELECT * FROM booking WHERE booking_date = '$booking_date' AND slot_id = '$rowTS[slot_id]'");
																			$rowCheckSlot = mysqli_fetch_array($sqlCheckSlot);
																			
																			if($rowTS['slot_id'] == $rowCheckSlot['slot_id'])
																			{
																				if($rowTS['slot_id'] == $slot_id)
																					echo "<option value='$rowTS[slot_id]|$rowTS[slot]' disabled selected>$rowTS[slot]</option>";
																				else
																					echo "<option value='$rowTS[slot_id]|$rowTS[slot]' disabled>$rowTS[slot]</option>";
																			}
																			else
																			{
																				if($rowTS['slot_id'] == $slot_id)
																					echo "<option value='$rowTS[slot_id]|$rowTS[slot]' selected>$rowTS[slot]</option>";
																				else
																					echo "<option value='$rowTS[slot_id]|$rowTS[slot]'>$rowTS[slot]</option>";
																			}
																		}
																			
																	
														echo"</select>
															</div>
													</div>";
												
												
											}
											
											if($showProceedBtn == "yes")
											{
												echo "<a href='check_availability.php?clinic_id=$_GET[clinic_id]&clinic_name=$_GET[clinic_name]' class='btn btn-dark btn-icon-split' type='reset'>
														<span class='icon text-white-50'>
															<i class='fas fa-dice'></i>
														</span>
														<span class='text'>Reset</span>
													</a>
													<button class='btn btn-primary btn-icon-split' type='submit' name='proceed'>
														<span class='icon text-white-50'>
															<i class='fas fa-chevron-circle-right'></i>
														</span>
														<span class='text'>Next</span>
													</button>";
											}
											if($showCheckBtn == "yes")
											{
												echo "<a href='check_availability.php?clinic_id=$_GET[clinic_id]&clinic_name=$_GET[clinic_name]' class='btn btn-dark btn-icon-split' type='reset'>
														<span class='icon text-white-50'>
															<i class='fas fa-dice'></i>
														</span>
														<span class='text'>Reset</span>
													</a>
													<button class='btn btn-primary btn-icon-split' type='submit' name='submit'>
														<span class='icon text-white-50'>
															<i class='fas fa-chevron-circle-right'></i>
														</span>
														<span class='text'>Check</span>
													</button>";
											}
										?>
										
										
										
										
									</form>
								</div>
							</div>

                        </div>
                    </div>
					
					
					<?php
					
					if($display == "yes")
					{
					?>
					<div class="row">

                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Booking Form</h6>
								</div>
								<div class="card-body">
								<?php
				  
									
							  ?>
									<form method="post" action="booking.php" enctype="multipart/form-data">
									<input type="hidden" name="booking_date" value="<?php echo $booking_date; ?>">
									<input type="hidden" name="slot_id" value="<?php echo $slot_id; ?>">
									<input type="hidden" name="clinic_id" value="<?php echo $clinic_id; ?>">
									<p class="card-description">
										<span class="text-primary">Fill in Booking Form</span>
									</p>
										<div class="row gx-3 mb-3">
                                                
                                                <div class="col-md-12">
                                                    <label class="small mb-1">Choose Pet</label>
                                                </div>
												
										</div>
										<div class="row gx-3 mb-3">
                                                
                                                <div class="col-md-12">
												  <div class="form-group">
												  
														<?php	
															$sqlPet = mysqli_query($conn, "SELECT * FROM pet WHERE owner_id = '$_SESSION[user_id]'");
															while($rowPet = mysqli_fetch_array($sqlPet))
															{
																echo "<input type='radio' id='$rowPet[pet_id]' name='pet_id' value='$rowPet[pet_id]' class='custom-radio-image' required />
																	<label for='$rowPet[pet_id]' class='radio-image-label'>
																	  <img src='pet/$rowPet[photo]' class='img-fluid' alt='$rowPet[pet_name]'>
																	</label>";
																
															}
																
														?>
												  </div>
                                                </div>
												
										</div>
										<div class="row gx-3 mb-3">
                                                
                                                <div class="col-md-12">
                                                    <label class="small mb-1">Treatment</label>
														<?php	
															$sqlTreatment = mysqli_query($conn, "SELECT * FROM treatment WHERE clinic_id = '$clinic_id'");
															while($rowTreatment = mysqli_fetch_array($sqlTreatment))
															{
																echo "<div class='form-check'>
																		<input class='form-check-input' id='$rowTreatment[treatment_id]' type='radio' name='treatment_id' value='$rowTreatment[treatment_id]' required />
																		<label class='form-check-label' for='$rowTreatment[treatment_id]'>$rowTreatment[treatment] - $rowTreatment[price]</label>
																	</div>";
															}
																
														?>
                                                </div>
												
										</div>
										<div class="row gx-3 mb-3">
                                                <div class="col-md-6">
                                                    <label class="small mb-1">Note</label>
                                                    <textarea class="form-control" name="note" rows="5" placeholder="Write some note here..." required ></textarea>
                                                </div>
										</div>
										
										
										<!-- Reset and Submit button-->
										<a class="btn btn-dark btn-icon-split" href="dashboard.php">
											<span class="icon text-white-50">
												<i class="fas fa-arrow-left"></i>
											</span>
											<span class="text">Cancel</span>
										</a>
										<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
											<span class="icon text-white-50">
												<i class="fas fa-check"></i>
											</span>
											<span class="text">Confirm</span>
										</button>
									</form>
								</div>
							</div>

                        </div>
                    </div>
					
				<?php
				}
				?>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>
	

</body>

</html>

<?php
}
?>