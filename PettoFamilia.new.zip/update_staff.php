<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	
	//post staff data
	$staff_id = $_POST['staff_id'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone_no = $_POST['phone_no'];
	$gender_id = $_POST['gender_id'];
	$experience = $_POST['experience'];

	$file_location 	= $_FILES['photo']['tmp_name'];
	$file_type		= $_FILES['photo']['type'];
	$file_name		= $_FILES['photo']['name'];
	
	if (empty($file_location))
	{
		$sql = mysqli_query($conn, "UPDATE clinic_staff SET name = '$name',
																email = '$email',
																phone_no = '$phone_no',
																gender_id = '$gender_id',
																experience = '$experience'
																WHERE staff_id = '$staff_id'");
	}
	else
	{
		move_uploaded_file($file_location,"photo/$file_name");
		
		$sql = mysqli_query($conn, "UPDATE clinic_staff SET name = '$name',
																email = '$email',
																phone_no = '$phone_no',
																gender_id = '$gender_id',
																experience = '$experience',
																photo = '$file_name',
																WHERE staff_id = '$staff_id'");
	}							
																	
	header('location:manage_staff.php');
}

?>