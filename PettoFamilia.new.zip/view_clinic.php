<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
.img-clinic
{
    height: 7rem;
}
</style>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Veterinary Clinic</h1>
						<small>View Veterinary Clinic</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">List of Veterinary Clinic</h6>
								</div>
								<div class="card-body">
									<?php
										
										$act = $_GET['act'];
										
										if ($act=='del')
										{
											$username =  $_GET['username'];
											$clinic_name =  $_GET['clinic_name'];
											
											$deleteAcc = mysqli_query($conn, "DELETE FROM login WHERE user_id = '$username'");
											$deleteClinic = mysqli_query($conn, "DELETE FROM clinic WHERE username = '$username'");
											
											if(($deleteAcc == true) && ($deleteClinic == true))
											{
												echo "<div class='alert alert-danger alert-dismissible fade show' role='alert'>
														  <strong>Thank you!</strong> Vet. Clinic <b>$clinic_name</b> successfully removed.
														  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
															<span aria-hidden='true'>&times;</span>
														  </button>
														</div>";
											}
												
										}
										else if ($act=='reset')
										{
											$username =  $_GET['username'];
											$clinic_name =  $_GET['clinic_name'];
											
											$sql = mysqli_query($conn, "UPDATE login SET password = '$username' WHERE user_id = '$username'");
											
											if($sql == true)
											{
												echo "<div class='alert alert-success alert-dismissible'>
															<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
															<strong>Thank you!</strong> Staff's Password for $clinic_name successfully reset. (New Password = $username).
													</div>";
											}
												
										}
										
										else if ($act=='update')
										{
											$clinic_name =  $_GET['clinic_name'];
																		
											echo "<div class='alert alert-success alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Thank you!</strong> Account for $clinic_name successfully updated.
													</div>";
										}
										
									?>
									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>No.</th>
													<th>Clinic</th>
													<th>License#</th>
													<th>Region</th>
													<th>Owner</th>
													<th>Email</th>
													<th>Tel. No.</th>
													<th>Open</th>
													<th>Close</th>
													<th>Picture</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												
												$no = 1;
												$sql = mysqli_query($conn, "SELECT * FROM clinic");
												while($row = mysqli_fetch_array($sql))
												{
													//get reggion name
													$sqlR = mysqli_query($conn, "SELECT * FROM region WHERE region_id = '$row[region_id]'");
													$rowR = mysqli_fetch_array($sqlR);
													
													echo "<tr>	
															<td>$no</td>
															<td>$row[clinic_name]</td>
															<td>$row[license_no]</td>
															<td>$row[owner_name]</td>
															<td>$rowR[region]</td>
															<td>$row[email]</td>
															<td>$row[tel_no]</td>
															<td>$row[open_time]</td>
															<td>$row[close_time]</td>
															<td>
																<img class='img-clinic' src='clinic/$row[picture]' alt='picture' />
															</td>
															<td>
																<a href='view_clinic.php?act=reset&username=$row[username]&clinic_name=$row[clinic_name]'
																	data-toggle='tooltip' data-placement='left' title='Reset Password'
																	onclick=\"return confirm('Are you sure you want to see password for Vet. Clinic $row[clinic_name]?');\">
																	<i class='fas fa-eye text-warning'></i>
																</a>
																
																<a href='#' data-toggle='modal'
																	data-target='#updateClinic$row[username]'>
																	<i class='fas fa-pen text-primary'></i>
																</a>
																	
																<a href='view_clinic.php?act=del&username=$row[username]&clinic_name=$row[clinic_name]'
																	data-toggle='tooltip' data-placement='left' title='Remove'
																	onclick=\"return confirm('Are you sure you want to remove Vet. Clinic $row[clinic_name]?');\">
																	<i class='fas fa-trash text-danger'></i>
																</a>
																</td>
															</tr>";
															
															
													
													$no++;
													include "modal_update_clinic.php";
												
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>