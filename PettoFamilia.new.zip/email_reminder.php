<?php
// Declare PHPMailer at the top
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	
	//post data
	$vaccination_id = $_POST['vaccination_id'];
	$owner_email = $_POST['owner_email'];
	$owner_name = $_POST['owner_name'];
	$pet_name = $_POST['pet_name'];
	$last_vaccinated = $_POST['last_vaccinated'];
	$expired_date = $_POST['expired_date'];
	
	$to = $owner_email;


	//date_default_timezone_set('Etc/UTC'); 
	date_default_timezone_set("Asia/Kuala_Lumpur");

	// Get the current date and time
	$current_datetime = date('Y-m-d H:i:s');
			
	// Use PHPMailer
	require 'PHPMailer/src/Exception.php';
	require 'PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/src/SMTP.php';
			
	$mail = new PHPMailer;
	$mail->isSMTP();
	$mail->SMTPDebug = 0;
	$mail->Debugoutput = 'html';
	$mail->Host = 'smtp.hostinger.com';
	$mail->Port = 587;
	$mail->SMTPSecure = 'tls';
	$mail->SMTPAuth = true;
	 
	//your account username
	$mail->Username = "noreply@oppahosting.online";
	 
	//your account Password to use for SMTP authentication
	$mail->Password = "test123!!!!A";
	 
	//your account username
	$mail->setFrom('noreply@oppahosting.online', 'Petto Familia');
	 
	//recipient
	$mail->addAddress($to);
	 
	$mail->isHTML(true);  // Set email format to HTML

	$random_number = rand(10000, 99999);

	$bodyContent .= "<b>Hello $owner_name,<br />This is the vaccination reminder email to remind you for your pet next vaccination.</b>";
	$bodyContent .= "<p>Pet Name : $pet_name";
	$bodyContent .= "<br />Last Vaccinated: $last_vaccinated";
	$bodyContent .= "<br />Expired Date: $expired_date</p>";
	$bodyContent .= "<p>Thank you.</p>";
	$bodyContent .= "<br /><i>This email was computer generated.  No Reply Required.</i>";

	$mail->Subject = '[ Petto Familia - Vaccination Reminder #' . $random_number . " ]";
	$mail->Body    = $bodyContent;

	if($mail->send())
	{
		//if email sent, update reminder status
		$sql = mysqli_query($conn, "UPDATE vaccination_reminder SET status = 'sent' WHERE vaccination_id = '$vaccination_id'");	
	
		$code = "sent";
	}
	else
	{
		$code = "notsent";
	}
	
	
	
	header('location:vaccination_reminder.php?code=' . $code);
}

?>