
			  <!-- Modal -->
              <div class="modal fade" id="updatePet<?php echo $row['pet_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                  <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <p class="modal-title"><i class="mdi mdi-lead-pencil text-success"></i> Update Your Pet Details</p>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>

                            <form method="post" action="update_pet.php" enctype="multipart/form-data">
							<input type="hidden" class="form-control" name="pet_id" value="<?php echo $row['pet_id']; ?>" readonly />
                            <div class="modal-body">
								<div class="row gx-3 mb-3">
									<div class="col-md-6">
										<label class="small mb-1">Pet Name</label>
										<input class="form-control" type="text" name="pet_name" value="<?php echo $row['pet_name']; ?>" placeholder="Your Pet Name" required />
									</div>
									<div class="col-md-6">
										<label class="small mb-1">Pet Type</label>
										<select name="type_id" class="form-control" required>
											<option value="">- choose type -</option>
											<?php
												$sqlType = mysqli_query($conn, "SELECT * FROM pet_type");
												while($rowType = mysqli_fetch_array($sqlType))
												{
													if($rowType['type_id'] == $row['type_id'])
														echo "<option value='$rowType[type_id]' selected>$rowType[type_name]</option>";
													else
														echo "<option value='$rowType[type_id]'>$rowType[type_name]</option>";
												}
														
											?>
										</select>
									</div>
								</div>
								<div class="row gx-3 mb-3">
									<div class="col-md-3">
										<label class="small mb-1">Age (Year)</label>
										<input class="form-control" type="number" name="age_year" value="<?php echo $row['age_year']; ?>" placeholder="Age (Year)" required />
									</div>
									<div class="col-md-3">
										<label class="small mb-1">Age (Month)</label>
										<input class="form-control" type="number" name="age_month" value="<?php echo $row['age_month']; ?>" placeholder="Age (Month)" required />
									</div>
									<div class="col-md-3">
										<label class="small mb-1">Sex</label>
										<select name="sex_id" class="form-control" required>
										<option value="">- choose sex -</option>
										<?php
											$sqlSex = mysqli_query($conn, "SELECT * FROM gender");
											while($rowSex = mysqli_fetch_array($sqlSex))
											{
												if($rowSex['gender_id'] == $row['sex_id'])
													echo "<option value='$rowSex[gender_id]' selected>$rowSex[gender]</option>";
												else
													echo "<option value='$rowSex[gender_id]'>$rowSex[gender]</option>";
											}
														
										?>
										</select>
									</div>
									<div class="col-md-3">
										<label class="small mb-1">Weight (KG)</label>
										<input class="form-control" type="text" name="weight" value="<?php echo $row['weight']; ?>" placeholder="Pet's Weight (KG)" required />
									</div>
								</div>
								<div class="row gx-3 mb-3">
									<div class="col-md-6">
										<label class="small mb-1">Genetic</label>
										<input class="form-control" type="text" name="genetic" value="<?php echo $row['genetic']; ?>" placeholder="Genetic" required />
									</div>
									<div class="col-md-6">
										<label class="small mb-1">New Photo <span class="text-warning">optional</span></label>
										<input class="form-control" type="file" name="photo" value="<?php echo $photo; ?>" placeholder="Photo" />
									</div>
								</div>
									  
                            </div>
                            <div class="modal-footer">
								<button class="btn btn-dark btn-icon-split" data-dismiss="modal">
									<span class="icon text-white-50">
										<i class="fas fa-window-close"></i>
									</span>
									<span class="text">Close</span>
								</button>
								<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
									<span class="icon text-white-50">
										<i class="fas fa-check"></i>
									</span>
									<span class="text">Update</span>
								</button>
                            </div>
							</form>
                        </div>
                  </div>
              </div>
              <!-- modal end -->