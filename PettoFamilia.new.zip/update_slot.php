<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	
	//post data
	$clinic_slot_id = $_POST['clinic_slot_id'];
	$slot_id = $_POST['slot_id'];
	
	$sql = mysqli_query($conn, "UPDATE clinic_slot SET slot_id = '$slot_id' WHERE clinic_slot_id = '$clinic_slot_id'");						
		
	header('location:manage_slot.php');
}

?>