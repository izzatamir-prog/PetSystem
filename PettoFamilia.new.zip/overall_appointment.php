<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Overall Appointment</h1>
						<small>Pet Treatment History for All Clinic</small>
                    </div>

                    <!-- Content Row -->
					
					
                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">List of All Appointment</h6>
								</div>
								<div class="card-body">
									
									<div class="table-responsive">
										<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
											<thead>
												<tr>
													<th>Booking#</th>
													<th>Clinic</th>
													<th>Date Time</th>
													<th>Pet</th>
													<th>Treatment</th>
													<th>Price</th>
													<th>Note</th>
													<th>Status</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php
												
												$sql = mysqli_query($conn, "SELECT * FROM booking");
												while($row = mysqli_fetch_array($sql))
												{
													//clinic name
													$sqlClinic = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$row[clinic_id]'");
													$rowClinic = mysqli_fetch_array($sqlClinic);
													
													//pet details
													$sqlPet = mysqli_query($conn, "SELECT * FROM pet WHERE pet_id = '$row[pet_id]'");
													$rowPet = mysqli_fetch_array($sqlPet);
													
													//slot
													$sqlSlot = mysqli_query($conn, "SELECT * FROM slot WHERE slot_id = '$row[slot_id]'");
													$rowSlot = mysqli_fetch_array($sqlSlot);
													
													//treatment
													$sqlTreatment = mysqli_query($conn, "SELECT * FROM treatment WHERE treatment_id = '$row[treatment_id]'");
													$rowTreatment = mysqli_fetch_array($sqlTreatment);
													
													
													//highlight booking status
													if($row['booking_status'] == "Booked")
														$booking_status = "<span class='badge badge-primary'>$row[booking_status]</span>";
													else if($row['booking_status'] == "Cancelled")
														$booking_status = "<span class='badge badge-danger'>$row[booking_status]</span>";
													else if($row['booking_status'] == "Upcoming")
														$booking_status = "<span class='badge badge-warning'>$row[booking_status]</span>";
													else if($row['booking_status'] == "Completed")
														$booking_status = "<span class='badge badge-success'>$row[booking_status]</span>";
																		
													//cek comment
													if($row['comment'] != NULL)
													{
														$comment = "<a href='#' data-toggle='modal'
																		data-target='#viewComent$row[booking_id]'>
																		<i class='fas fa-comments text-primary'></i>
																	</a>";
													}
													else if($row['comment'] == NULL)
													{
														$comment = "<span class='badge badge-warning'>- - -</span>";
													}

													echo "<tr>	
															<td>$row[booking_id]</td>
															<td>$rowClinic[clinic_name]</td>
															<td>$row[booking_date]<br />($rowSlot[slot])</td>				
															<td>$rowPet[pet_name]</td>
															<td>$rowTreatment[treatment]</td>
															<td>$rowTreatment[price]</td>
															<td>$row[note]</td>
															<td>$booking_status</td>
															<td>$comment</td>
															</tr>";
																	
															include "modal_view_comment.php";
												}
												?>
											</tbody>
										</table>
									</div>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>