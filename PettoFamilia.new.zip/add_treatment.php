<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>
				<!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Pet Treatment</h1>
						<small>Treatment Offered by Your Clinic</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Pet Treatment Details</h6>
								</div>
								<div class="card-body">
									<?php
										
										if (isset($_POST['submit']))
										{
											//post data
											$treatment_id = $_POST['treatment_id'];
											$treatment = $_POST['treatment'];
											$price = $_POST['price'];
											$description = $_POST['description'];
											$clinic_id = $_SESSION['user_id'];
											
											//echo "treatment_id " . $treatment_id;
											
											
											$sql = mysqli_query($conn, "INSERT INTO treatment (treatment_id,
																								treatment,
																								price,
																								description,
																								clinic_id)
																						VALUES ('$treatment_id',
																								'$treatment',
																								'$price',
																								'$description',
																								'$clinic_id')");
											
											if($sql == true)
											{
												
													$treatment = "";
													$price = "";
													$description = "";
											
													echo "<div class='alert alert-success alert-dismissible'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																<strong>Thank you!</strong> Treatment details succefully added.
															</div>";
												
												
											}
											else
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> error.
													</div>";
				
										}
										
										//generate random 5 string
										function generateRandomString($length = 5) {
											$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
											$charactersLength = strlen($characters);
											$randomString = '';
											for ($i = 0; $i < $length; $i++) {
												$randomString .= $characters[rand(0, $charactersLength - 1)];
											}
											return $randomString;
										}
										
										$clinic_id_upper_case = strtoupper($_SESSION['user_id']);
										do
										{
											$treatment_id = "T" . $clinic_id_upper_case . generateRandomString();
											
											//cek samada id dah wujud atau belum. jika dah wujud generate id baru
											$sqlCheck = mysqli_query($conn, "SELECT * FROM treatment WHERE treatment_id = '$treatment_id'");
											$numRowCheck = mysqli_num_rows($sqlCheck);
											
										}while($numRowCheck > 0);
									?>
									<form method="post" enctype="multipart/form-data">
										<div class="row gx-3 mb-3">
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Treatment ID</label>
                                                    <input class="form-control" type="text" name="treatment_id" value="<?php echo $treatment_id; ?>" placeholder="Treatment ID" readonly />
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="small mb-1">Treatment Name</label>
                                                    <input class="form-control" type="text" name="treatment" value="<?php echo $treatment; ?>" placeholder="Treatment Name" required />
                                                </div>
                                                <div class="col-md-3">
                                                    <label class="small mb-1">Price (RM)</label>
                                                    <input class="form-control" type="number" name="price" value="<?php echo $price; ?>" placeholder="Price (RM)" required />
                                                </div>
										</div>
										
										<div class="row gx-3 mb-3">
                                                <div class="col-md-12">
                                                    <label class="small mb-1">Description</label>
                                                    <textarea class="form-control" name="description" rows="5" placeholder="Write treatment description here..." required ><?php echo $description; ?></textarea>
                                                </div>
										</div>
										
										<!-- Reset and Submit button-->
										<button class="btn btn-dark btn-icon-split" type="reset">
											<span class="icon text-white-50">
												<i class="fas fa-dice"></i>
											</span>
											<span class="text">Reset</span>
										</button>
										<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
											<span class="icon text-white-50">
												<i class="fas fa-check"></i>
											</span>
											<span class="text">Submit</span>
										</button>
									</form>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>