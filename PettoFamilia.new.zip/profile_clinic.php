<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>
				
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Profile</h1>
						<small>Clinic Profile</small>
                    </div>

                    <!-- Content Row -->

                    <div class="row">


                        <div class="col-lg-12 mb-4">
                            <!-- DataTales Example -->
							<div class="card shadow mb-4">
								<div class="card-header py-3">
									<h6 class="m-0 font-weight-bold text-primary">Update your clinic profile if necessary</h6>
								</div>
								<div class="card-body">
									<?php
									
										if (isset($_POST['submit']))
										{
											$username = $_POST['username'];
											$clinic_name = $_POST['clinic_name'];
											$owner_name = $_POST['owner_name'];
											$region_id = $_POST['region_id'];
											$tel_no = $_POST['tel_no'];
											$open_time = $_POST['open_time'];
											$close_time = $_POST['close_time'];
											$email = $_POST['email'];
											
											$file_location 	= $_FILES['picture']['tmp_name'];
											$file_type		= $_FILES['picture']['type'];
											$file_name		= $_FILES['picture']['name'];
											
											if (empty($file_location))
											{
												$sql = mysqli_query($conn, "UPDATE clinic SET clinic_name = '$clinic_name',
																										owner_name = '$owner_name',
																										region_id = '$region_id',
																										email = '$email',
																										tel_no = '$tel_no',
																										open_time = '$open_time',
																										close_time = '$close_time'
																										WHERE username = '$username'");
											}
											else
											{
												move_uploaded_file($file_location,"clinic/$file_name");
												
												$sql = mysqli_query($conn, "UPDATE clinic SET clinic_name = '$clinic_name',
																										owner_name = '$owner_name',
																										region_id = '$region_id',
																										email = '$email',
																										tel_no = '$tel_no',
																										open_time = '$open_time',
																										close_time = '$close_time',
																										picture = '$file_name'
																										WHERE username = '$username'");
											}
											
											if($sql == true)
											{
													echo "<div class='alert alert-success alert-dismissible'>
																<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
																<strong>Thank you!</strong> Your clinic profile is successfully updated.
															</div>";
												
											}
											else
											{
												echo "<div class='alert alert-danger alert-dismissible'>
														<a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
														<strong>Sorry!</strong> error.
													</div>";
											}
				
										}
										
										//get clinic details
										$sql = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$_SESSION[user_id]'");
										$row = mysqli_fetch_array($sql); 
										
									?>
									<form method="post" enctype="multipart/form-data">
										<div class="row gx-3 mb-3">
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Clinic ID</label>
                                                    <input class="form-control" type="text" name="username" value="<?php echo $row['username']; ?>" placeholder="Clinic ID" readonly />
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Clinic Vet Name</label>
                                                    <input class="form-control" type="text" name="clinic_name" value="<?php echo $row['clinic_name']; ?>" placeholder="Clinic Vet Name" required />
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Owner Name</label>
                                                    <input class="form-control" type="text" name="owner_name" value="<?php echo $row['owner_name']; ?>" placeholder="Owner Name" required />
                                                </div>
										</div>
										<div class="row gx-3 mb-3">
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Region</label>
                                                    <select class="form-control" name="region_id" required>
														<option value="">- choose region -</option>
														<?php
															$sqlRegion = mysqli_query($conn, "SELECT * FROM region");
															while($rowRegion = mysqli_fetch_array($sqlRegion))
															{
																if($rowRegion['region_id'] == $row['region_id'])
																	echo "<option value='$rowRegion[region_id]' selected>$rowRegion[region]</option>";
																else
																	echo "<option value='$rowRegion[region_id]'>$rowRegion[region]</option>";
															}
														?>
													</select>
                                                </div>
                                                <div class="col-md-4">
													<label class="small mb-1">Email</label>
													<input class="form-control" type="email" name="email" value="<?php echo $row['email']; ?>" placeholder="Email Address" required />
                                                </div>
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Tel. No.</label>
                                                    <input class="form-control" type="number" name="tel_no" value="<?php echo $row['tel_no']; ?>" placeholder="Phone No." required />
                                                </div>
										</div>
										<div class="row gx-3 mb-3">
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Open Time</label>
													<input class="form-control" type="time" name="open_time" value="<?php echo $row['open_time']; ?>" placeholder="Open Time" required />
                                                </div>
                                                <div class="col-md-4">
                                                   <label class="small mb-1">Close Time</label>
													<input class="form-control" type="time" name="close_time" value="<?php echo $row['close_time']; ?>" placeholder="Close Time" required />
												</div>
                                                <div class="col-md-4">
                                                    <label class="small mb-1">Clinic Picture <span class="badge badge-warning">(if necessary)</span></label>
                                                    <input class="form-control" type="file" name="photo" />
                                                </div>
										</div>
										
										<!-- Reset and Submit button-->
										<button class="btn btn-dark btn-icon-split" type="reset">
											<span class="icon text-white-50">
												<i class="fas fa-dice"></i>
											</span>
											<span class="text">Reset</span>
										</button>
										<button class="btn btn-primary btn-icon-split" type="submit" name="submit">
											<span class="icon text-white-50">
												<i class="fas fa-check"></i>
											</span>
											<span class="text">Update</span>
										</button>
									</form>
								</div>
							</div>

                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>

</body>

</html>

<?php
}
?>