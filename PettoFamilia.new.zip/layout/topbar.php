                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-outline-dark d-md-none mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
					
					<!-- Sidebar Toggler (Sidebar)  -->
					<div class="text-center d-none d-md-inline">
						<button class="btn btn-outline-dark mr-3" id="sidebarToggle"><i class="fa fa-bars"></i></button>
					</div>
					

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <?php
						
							//display notification only for clinic
							/*
							if($_SESSION['level'] == 2)
							{
								echo "<!-- Nav Item - Alerts -->
										<li class='nav-item dropdown no-arrow mx-1'>
											<a class='nav-link dropdown-toggle' href='#' id='alertsDropdown' role='button'
												data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
												<i class='fas fa-bell fa-fw'></i>
												<!-- Counter - Alerts -->
												<span class='badge badge-danger badge-counter'>3+</span>
											</a>
											<!-- Dropdown - Alerts -->
											<div class='dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in'
												aria-labelledby='alertsDropdown'>
												<h6 class='dropdown-header'>
													Notification
												</h6>
												<a class='dropdown-item d-flex align-items-center' href='#'>
													<div class='mr-3'>
														<div class='icon-circle bg-primary'>
															<i class='fas fa-file-alt text-white'></i>
														</div>
													</div>
													<div>
														<div class='small text-gray-500'>March 12, 2024</div>
														<span class='font-weight-bold'>Sample notification #####!</span>
													</div>
												</a>
												<a class='dropdown-item d-flex align-items-center' href='#'>
													<div class='mr-3'>
														<div class='icon-circle bg-success'>
															<i class='fas fa-donate text-white'></i>
														</div>
													</div>
													<div>
														<div class='small text-gray-500'>March 11, 2024</div>
														Sample notification #####!
													</div>
												</a>
												<a class='dropdown-item d-flex align-items-center' href='#'>
													<div class='mr-3'>
														<div class='icon-circle bg-warning'>
															<i class='fas fa-exclamation-triangle text-white'></i>
														</div>
													</div>
													<div>
														<div class='small text-gray-500'>March 10, 2024</div>
														Sample notification #####!
													</div>
												</a>
												<a class='dropdown-item text-center small text-gray-500' href='#'>Show All Notification</a>
											</div>
										</li>
										<div class='topbar-divider d-none d-sm-block'></div>";
							}
							*/
						?>

                        
                        
						
						<?php
						
							//right top menu admin
							if($_SESSION['level'] == 1)
							{
								//get admin details
								$sql = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$_SESSION[user_id]'");
								$row = mysqli_fetch_array($sql);
								
								//get current session user name
								$name = $row['name'];
								
								echo "<!-- Nav Item - User Information -->
										<li class='nav-item dropdown no-arrow'>
											<a class='nav-link dropdown-toggle' href='#' id='userDropdown' role='button'
												data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
												<span class='mr-2 d-none d-lg-inline text-gray-600 small'>$row[name]</span>
												<img class='img-profile rounded-circle'
													src='photo/$row[photo]'>
											</a>
											<!-- Dropdown - User Information -->
											<div class='dropdown-menu dropdown-menu-right shadow animated--grow-in'
												aria-labelledby='userDropdown'>
												<a class='dropdown-item' href='profile_admin.php'>
													<i class='fas fa-user fa-sm fa-fw mr-2 text-gray-400'></i>
													Profile
												</a>
												<a class='dropdown-item' href='update_password.php'>
													<i class='fas fa-cogs fa-sm fa-fw mr-2 text-gray-400'></i>
													Password
												</a>
												<div class='dropdown-divider'></div>
												<a class='dropdown-item' href='logout.php'>
													<i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400'></i>
													Logout
												</a>
											</div>
										</li>";
							}
							
							//right top menu clinic
							else if($_SESSION['level'] == 2)
							{
								//get clinic details
								$sql = mysqli_query($conn, "SELECT * FROM clinic WHERE username = '$_SESSION[user_id]'");
								$row = mysqli_fetch_array($sql);
								
								
								echo "<!-- Nav Item - User Information -->
										<li class='nav-item dropdown no-arrow'>
											<a class='nav-link dropdown-toggle' href='#' id='userDropdown' role='button'
												data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
												<span class='mr-2 d-none d-lg-inline text-gray-600 small'>$row[clinic_name]</span>
												<img class='img-profile rounded-circle'
													src='clinic/$row[picture]'>
											</a>
											<!-- Dropdown - User Information -->
											<div class='dropdown-menu dropdown-menu-right shadow animated--grow-in'
												aria-labelledby='userDropdown'>
												<a class='dropdown-item' href='profile_clinic.php'>
													<i class='fas fa-user fa-sm fa-fw mr-2 text-gray-400'></i>
													Profile
												</a>
												<a class='dropdown-item' href='update_password.php'>
													<i class='fas fa-cogs fa-sm fa-fw mr-2 text-gray-400'></i>
													Password
												</a>
												<div class='dropdown-divider'></div>
												<a class='dropdown-item' href='logout.php'>
													<i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400'></i>
													Logout
												</a>
											</div>
										</li>";
							}
							
							//right top menu pet owner
							else if($_SESSION['level'] == 3)
							{
								//get pet owner details
								$sql = mysqli_query($conn, "SELECT * FROM owner WHERE username = '$_SESSION[user_id]'");
								$row = mysqli_fetch_array($sql);
								
								//get current session user name
								$name = $row['name'];
								
								echo "<!-- Nav Item - User Information -->
										<li class='nav-item dropdown no-arrow'>
											<a class='nav-link dropdown-toggle' href='#' id='userDropdown' role='button'
												data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>
												<span class='mr-2 d-none d-lg-inline text-gray-600 small'>$row[name]</span>
												<img class='img-profile rounded-circle'
													src='photo/$row[photo]'>
											</a>
											<!-- Dropdown - User Information -->
											<div class='dropdown-menu dropdown-menu-right shadow animated--grow-in'
												aria-labelledby='userDropdown'>
												<a class='dropdown-item' href='profile_pet_owner.php'>
													<i class='fas fa-user fa-sm fa-fw mr-2 text-gray-400'></i>
													Profile
												</a>
												<a class='dropdown-item' href='update_password.php'>
													<i class='fas fa-cogs fa-sm fa-fw mr-2 text-gray-400'></i>
													Password
												</a>
												<div class='dropdown-divider'></div>
												<a class='dropdown-item' href='logout.php'>
													<i class='fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400'></i>
													Logout
												</a>
											</div>
										</li>";
							}
						?>

                        

                    </ul>

                </nav>
                <!-- End of Topbar -->