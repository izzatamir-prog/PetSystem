        <!-- Sidebar -->
        
		<?php
			if($_SESSION['level'] == 1)
			{
				echo "<ul class='navbar-nav bg-gradient-danger sidebar sidebar-dark accordion' id='accordionSidebar'>

							<!-- Sidebar - Brand -->
							<a class='sidebar-brand d-flex align-items-center justify-content-center' href='index.html'>
								<div class='sidebar-brand-text mx-3'>Petto Familia <sup>v1</sup></div>
							</a>

							<!-- Divider -->
							<hr class='sidebar-divider my-0'>

							<!-- Nav Item - Dashboard -->
							<li class='nav-item active'>
								<a class='nav-link' href='index.php'>
									<i class='fas fa-fw fa-tachometer-alt'></i>
									<span>Dashboard</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Management
							</div>
							
							<!-- Nav Item - Pet Owner -->
							<li class='nav-item'>
								<a class='nav-link' href='owner.php'>
									 <i class='fas fa-fw fa-folder'></i>
									<span>Owner</span></a>
							</li>

							<!-- Nav Item - Staff -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#collapseTwo'
									aria-expanded='true' aria-controls='collapseTwo'>
									<i class='fas fa-fw fa-user'></i>
									<span>Clinic &amp; Staff</span>
								</a>
								<div id='collapseTwo' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Clinic &amp; Staff Management:</h6>
										<a class='collapse-item' href='add_clinic_staff.php'>Add Clinic's Staff</a>
										<a class='collapse-item' href='manage_clinic_staff.php'>Manage Clinic's Staff</a>
									</div>
								</div>
							</li>
							

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Report
							</div>

							<!-- Nav Item - Generate Report -->
							<li class='nav-item'>
								<a class='nav-link' href='#'>
									<i class='fas fa-fw fa-chart-area'></i>
									<span>Report</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider d-none d-md-block'>

						</ul>";
			}
			else if($_SESSION['level'] == 3)
			{
				echo "<ul class='navbar-nav bg-gradient-danger sidebar sidebar-dark accordion' id='accordionSidebar'>

							<!-- Sidebar - Brand -->
							<a class='sidebar-brand d-flex align-items-center justify-content-center' href='index.html'>
								<div class='sidebar-brand-text mx-3'>Petto Familio <sup>v1</sup></div>
							</a>

							<!-- Divider -->
							<hr class='sidebar-divider my-0'>

							<!-- Nav Item - Dashboard -->
							<li class='nav-item active'>
								<a class='nav-link' href='index.php'>
									<i class='fas fa-fw fa-tachometer-alt'></i>
									<span>Dashboard</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Management
							</div>

							<!-- Nav Item - Pet -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#collapseThree'
									aria-expanded='true' aria-controls='collapseThree'>
									<i class='fas fa-fw fa-user'></i>
									<span>Pet</span>
								</a>
								<div id='collapseThree' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Pet Management:</h6>
										<a class='collapse-item' href='pet_registration.php'>Pet Registration</a>
										<a class='collapse-item' href='manage_pet.php'>Manage Pet</a>
									</div>
								</div>
							</li>

							<!-- Nav Item - Treatment -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#collapseFour'
									aria-expanded='true' aria-controls='collapseFour'>
									<i class='fas fa-fw fa-user'></i>
									<span>Treatment</span>
								</a>
								<div id='collapseFour' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Treatment Management:</h6>
										<a class='collapse-item' href='book_treatment.php'>Book Treatment</a>
										<a class='collapse-item' href='treatment_history.php'>Treatment History</a>
									</div>
								</div>
							</li>
							
							<!-- Divider -->
							<hr class='sidebar-divider d-none d-md-block'>

						</ul>";
			}
		?>
        <!-- End of Sidebar -->
