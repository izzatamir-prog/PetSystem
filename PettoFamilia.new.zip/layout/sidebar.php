        <!-- Sidebar -->
        
		<?php
			if($_SESSION['level'] == 1)
			{
				echo "<ul class='navbar-nav bg-gradient-danger sidebar sidebar-dark accordion' id='accordionSidebar'>

							<!-- Sidebar - Brand -->
							<a class='sidebar-brand d-flex align-items-center justify-content-center' href='index.php'>
								<div class='sidebar-brand-text mx-3'>Petto Familia</div>
							</a>

							<!-- Divider -->
							<hr class='sidebar-divider my-0'>

							<!-- Nav Item - Dashboard -->
							<li class='nav-item active'>
								<a class='nav-link' href='index.php'>
									<i class='menu-icon icon icon-grid text-white'></i>
									<span>Dashboard</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Management
							</div>
							
							<!-- Nav Item - Pet Owner -->
							<li class='nav-item'>
								<a class='nav-link' href='owner.php'>
									<i class='menu-icon icon icon-user-following text-white'></i>
									<span>Pet Owner</span></a>
							</li>
							
							<!-- Nav Item - Clinic -->
							<li class='nav-item'>
								<a class='nav-link' href='view_clinic.php'>
									<i class='menu-icon icon icon-docs text-white'></i>
									<span>Clinic</span></a>
							</li>
							
							<!-- Nav Item - Appointment -->
							<li class='nav-item'>
								<a class='nav-link' href='overall_appointment.php'>
									<i class='menu-icon icon icon-book-open text-white'></i>
									<span>Appointment</span></a>
							</li>
							

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Report
							</div>

							<!-- Nav Item - Generate Report -->
							<li class='nav-item'>
								<a class='nav-link' href='clinic_report.php'>
									<i class='menu-icon icon icon-chart text-white'></i>
									<span>Report</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider d-none d-md-block'>

						</ul>";
			}
			else if($_SESSION['level'] == 2)
			{
				echo "<ul class='navbar-nav bg-gradient-danger sidebar sidebar-dark accordion' id='accordionSidebar'>

							<!-- Sidebar - Brand -->
							<a class='sidebar-brand d-flex align-items-center justify-content-center' href='index.php'>
								<div class='sidebar-brand-text mx-3'>Petto Familia</div>
							</a>

							<!-- Divider -->
							<hr class='sidebar-divider my-0'>

							<!-- Nav Item - Dashboard -->
							<li class='nav-item active'>
								<a class='nav-link' href='index.php'>
									<i class='menu-icon icon icon-grid text-white'></i>
									<span>Dashboard</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Management
							</div>
							
							<!-- Nav Item - Slot -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#slot'
									aria-expanded='true' aria-controls='slot'>
									<i class='menu-icon icon icon-clock text-white'></i>
									<span>Slot</span>
								</a>
								<div id='slot' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Slot Management:</h6>
										<a class='collapse-item' href='add_slot.php'>Add Slot</a>
										<a class='collapse-item' href='manage_slot.php'>Manage Slot</a>
									</div>
								</div>
							</li>
							
							<!-- Nav Item - Treatment -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#collapseTwo'
									aria-expanded='true' aria-controls='collapseTwo'>
									<i class='menu-icon icon icon-notebook text-white'></i>
									<span>Treatment</span>
								</a>
								<div id='collapseTwo' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Treatment Management:</h6>
										<a class='collapse-item' href='add_treatment.php'>Add Treatment</a>
										<a class='collapse-item' href='manage_treatment.php'>Manage Treatment</a>
									</div>
								</div>
							</li>
							
							<!-- Nav Item - Clinic -->
							<li class='nav-item'>
								<a class='nav-link' href='manage_appointment.php'>
									<i class='menu-icon icon icon-book-open text-white'></i>
									<span>Appointment</span></a>
							</li>
							
							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Reminder
							</div>

							<!-- Nav Item - Reminder -->
							<li class='nav-item'>
								<a class='nav-link' href='vaccination_reminder.php'>
									<i class='menu-icon icon icon-envelope-letter text-white'></i>
									<span>Vaccination</span></a>
							</li>
							

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Report
							</div>

							<!-- Nav Item - Generate Report -->
							<li class='nav-item'>
								<a class='nav-link' href='report.php'>
									<i class='menu-icon icon icon-chart text-white'></i>
									<span>Report</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider d-none d-md-block'>

						</ul>";
			}
			else if($_SESSION['level'] == 3)
			{
				echo "<ul class='navbar-nav bg-gradient-danger sidebar sidebar-dark accordion' id='accordionSidebar'>

							<!-- Sidebar - Brand -->
							<a class='sidebar-brand d-flex align-items-center justify-content-center' href='index.php'>
								<div class='sidebar-brand-text mx-3'>Petto Familia</div>
							</a>

							<!-- Divider -->
							<hr class='sidebar-divider my-0'>

							<!-- Nav Item - Dashboard -->
							<li class='nav-item active'>
								<a class='nav-link' href='index.php'>
									<i class='fas fa-fw fa-tachometer-alt'></i>
									<span>Dashboard</span></a>
							</li>

							<!-- Divider -->
							<hr class='sidebar-divider'>

							<!-- Heading -->
							<div class='sidebar-heading'>
								Management
							</div>

							<!-- Nav Item - Pet -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#collapseThree'
									aria-expanded='true' aria-controls='collapseThree'>
									<i class='fas fa-fw fa-user'></i>
									<span>Pet</span>
								</a>
								<div id='collapseThree' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Pet Management:</h6>
										<a class='collapse-item' href='pet_registration.php'>Pet Registration</a>
										<a class='collapse-item' href='manage_pet.php'>Manage Pet</a>
									</div>
								</div>
							</li>

							<!-- Nav Item - Treatment -->
							<li class='nav-item'>
								<a class='nav-link collapsed' href='#' data-toggle='collapse' data-target='#collapseFour'
									aria-expanded='true' aria-controls='collapseFour'>
									<i class='fas fa-fw fa-user'></i>
									<span>Treatment</span>
								</a>
								<div id='collapseFour' class='collapse' aria-labelledby='headingTwo' data-parent='#accordionSidebar'>
									<div class='bg-white py-2 collapse-inner rounded'>
										<h6 class='collapse-header'>Treatment Management:</h6>
										<a class='collapse-item' href='book_treatment.php'>Book Treatment</a>
										<a class='collapse-item' href='treatment_history.php'>Treatment History</a>
									</div>
								</div>
							</li>
							
							<!-- Divider -->
							<hr class='sidebar-divider d-none d-md-block'>

						</ul>";
			}
		?>
        <!-- End of Sidebar -->
