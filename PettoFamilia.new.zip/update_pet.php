<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
	$pet_id = $_POST['pet_id'];
	$pet_name = $_POST['pet_name'];
	$type_id = $_POST['type_id'];
	$age_year = $_POST['age_year'];
	$age_month = $_POST['age_month'];
	$sex_id = $_POST['sex_id'];
	$weight = $_POST['weight'];
	$genetic = $_POST['genetic'];
	
	$file_location 	= $_FILES['photo']['tmp_name'];
	$file_type		= $_FILES['photo']['type'];
	$file_name		= $_FILES['photo']['name'];
	
	if (empty($file_location))
	{
		$sql = mysqli_query($conn, "UPDATE pet SET pet_name = '$pet_name',
														type_id = '$type_id',
														age_year = '$age_year',
														age_month = '$age_month',
														sex_id = '$sex_id',
														weight = '$weight',
														genetic = '$genetic'
														WHERE pet_id = '$pet_id'");
	}
	else
	{
		move_uploaded_file($file_location,"pet/$file_name");
		
		$sql = mysqli_query($conn, "UPDATE pet SET pet_name = '$pet_name',
														type_id = '$type_id',
														age_year = '$age_year',
														age_month = '$age_month',
														sex_id = '$sex_id',
														weight = '$weight',
														genetic = '$genetic',
														photo = '$file_name'
														WHERE pet_id = '$pet_id'");
	}
						
	
											
																	
	header('location:manage_pet.php');
}

?>