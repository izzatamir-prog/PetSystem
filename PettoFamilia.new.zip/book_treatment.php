<?php
include "conn/conn.php";
error_reporting(0);
session_start();
if (empty($_SESSION['user_id']) AND empty($_SESSION['password']))
{
  header('location:index.php');
}
else
{
?>
<!DOCTYPE html>
<html lang="en">

<!-- Head -->
<?php include("layout/head.php"); ?>
<style>
	
	#loadMore {
		padding-bottom: 30px;
		padding-top: 30px;
		text-align: center;
		width: 100%;
	}
	#loadMore a {
		display: inline-block;
		padding: 10px 30px;
		transition: all 0.25s ease-out;
		-webkit-font-smoothing: antialiased;
	}
</style>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
		<?php include("layout/sidebar.php"); ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                 <!-- Topbar -->
				<?php include("layout/topbar.php"); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Book Treatment</h1>
						<small>Check Availability &amp; Book Treatment</small>
                    </div>

                    <!-- Content Row -->
					
					<div class="row">
				  <?php
						
						
						
							$counter = 0;
							$hideStyle = "";
							
							$sql = mysqli_query($conn, "SELECT * FROM clinic");					
							while($row = mysqli_fetch_array($sql))
							{
								//get region name
								$sqlR = mysqli_query($conn, "SELECT * FROM region WHERE region_id = '$row[region_id]'");
								$rowR = mysqli_fetch_array($sqlR);
								
								echo "<div class='col-md-3 grid-margin stretch-card blogBox moreBox' $hideStyle>
										<div class='card'>
										  <img class='card-img-top' src='clinic/$row[picture]' alt='card images' style='height:300px'>
										  <div class='card-body text-center pb-0'>
											<p class='text-muted'>$row[clinic_name]</p>
											<small class='text-success'>Region : $rowR[region]</small><br />
											<small class='text-warning'>Open :  $row[open_time] until $row[close_time]</small>
											<div class='d-flex align-items-center justify-content-between text-muted border-top py-3 mt-3'>
											  <div class='wrapper d-flex align-items-center'>
												<a href='#' data-toggle='modal'
													data-target='#clinic$row[username]'>
													<i class='icon icon-info'></i>
													Details
												</a>
											  </div>
											  <p class='mb-0'>
												<a href='check_availability.php?clinic_id=$row[username]&clinic_name=$row[clinic_name]' class='btn btn-outline-primary btn-lg'>
												<i class='mdi mdi-check'></i> Book</a>
												</p>
											  
											</div>
										  </div>
										</div>
									  </div>";
															
								
										
									$counter++;
									include "modal_clinic.php";
								
									if($counter > 2)
										$hideStyle = "style='display: none;'";
							}
							
							echo "<div id='loadMore' style=''>
										<a href='#' class='btn mb-1 btn-outline-primary'><i class='mdi mdi-arrow-down'></i> View More</a>
									</div>";
						
						
						
					?>
					
				  </div>
          

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include("layout/footer.php"); ?>

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Javascript -->
	<?php include("layout/script.php"); ?>
	
   <script>
	$( document ).ready(function () {
	  $(".moreBox").slice(0, 4).show();
		if ($(".blogBox:hidden").length != 0) {
		  $("#loadMore").show();
		}   
		$("#loadMore").on('click', function (e) {
		  e.preventDefault();
		  $(".moreBox:hidden").slice(0, 4).slideDown();
		  if ($(".moreBox:hidden").length == 0) {
			$("#loadMore").fadeOut('slow');
		  }
		});
	  });
   </script>

</body>

</html>

<?php
}
?>